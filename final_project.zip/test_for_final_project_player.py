#############################################################
# FILE : test_for_final_project_player.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: test for player class for chinese checkers game
#############################################################

import pytest
from constants import *
from player import Player


def test_get_name():
    player = Player('Dani')
    assert player.get_name() == 'Dani', 'The name of the player should be Dani'
    player = Player('moshe')
    assert player.get_name() == 'Moshe', 'The name of the player should be Moshe'
    player = Player('R')
    assert player.get_name() == 'R', 'The name of the player should be R'
    with pytest.raises(ValueError):
        Player(''), "Empty name should raise ValueError"
    with pytest.raises(ValueError):
        Player(' '), "name first char can't be capitalize, should raise ValueError"
    with pytest.raises(ValueError):
        Player(1), "name should be string, should raise ValueError"
    with pytest.raises(ValueError):
        Player(["Dan"]), "name should be string, should raise ValueError"
    with pytest.raises(ValueError):
        Player('1'), "name first char can't be capitalize, should raise ValueError"
    with pytest.raises(ValueError):
        Player('dani avdija'), "name should be one word, should raise ValueError"


def test_set_and_get_color():
    player = Player('Dani')
    assert player.get_color() == 'W', 'The color of the player should be W'

    player = Player('Josh_Giddey')
    player.set_color('R')
    assert player.get_color() == 'R', 'The color of the player should be R'
    for piece in player.get_pieces_of_player():
        assert piece.get_color() == 'R', 'All pieces should be R'

    player = Player('r-$5')
    player.set_color('Y')
    assert player.get_color() == 'Y', 'The color of the player should be Y'

    player = Player('Chet_Holmgren')
    player.set_color('P')
    assert player.get_color() == 'P', 'The color of the player should be P'
    for piece in player.get_pieces_of_player():
        assert piece.get_color() == 'P', 'All pieces should be P'

    player = Player('Victor_Wembanyama')
    with pytest.raises(ValueError):
        player.set_color('Blue'), "Unavailable color (should be one letter), should raise ValueError"

    player = Player('Jalen_Williams')
    with pytest.raises(ValueError):
        player.set_color(''), "Empty color, should raise ValueError"

    player = Player('Jalyin_Williams')
    with pytest.raises(ValueError):
        player.set_color("O"), "Unavailable color, should raise ValueError"
    for piece in player.get_pieces_of_player():
        assert piece.get_color() == 'W', 'All pieces should be W'

    player = Player('Jalen_Duren')
    with pytest.raises(ValueError):
        player.set_color(1), "color should be string, should raise ValueError"

    player = Player('Jaden_Ivey')
    with pytest.raises(ValueError):
        player.set_color('r'), "color should be R"


def test_set_number_of_pieces():
    player = Player('Dani')
    player.set_number_of_pieces(15)
    assert len(player.get_pieces_of_player()) == 15, "The number of pieces should be 15"
    assert len(player.get_pieces_of_player()) == 15, "The number of pieces should be 15"
    player.set_number_of_pieces(10)
    assert len(player.get_pieces_of_player()) == 10, "The number of pieces should be 10"

    with pytest.raises(ValueError):
        player.set_number_of_pieces(7), "number of pieces should be 10/15, should raise ValueError"

    with pytest.raises(ValueError):
        player.set_number_of_pieces(16), "number of pieces should be 10/15, should raise ValueError"

    with pytest.raises(ValueError):
        player.set_number_of_pieces('15'), "number of pieces should be int, should raise ValueError"

    with pytest.raises(ValueError):
        player.set_number_of_pieces(15.5), "number of pieces should be int, should raise ValueError"


def test_home_cells_and_get_pieces_of_player():
    player = Player('Dani_Avdija')
    list_of_coordinates = Constants.DICT_OF_TRIANGLES['1']
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinates, 'All pieces should be in the home cells'

    player.set_home_cells("2")
    list_of_coordinates = Constants.DICT_OF_TRIANGLES['2']
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinates, 'All pieces should be in the home cells'

    with pytest.raises(ValueError):
        player.set_home_cells(1), "home cells should be string, should raise ValueError"

    with pytest.raises(ValueError):
        player.set_home_cells('upper'), "invalid home triangle, should raise ValueError"

    with pytest.raises(ValueError):
        player.set_home_cells('9'), "out of range, should raise ValueError"

    player = Player('Ran')
    player.set_color('R')
    player.set_number_of_pieces(15)
    player.set_home_cells("B")
    assert len(player.get_pieces_of_player()) == 15, "The number of pieces should be 15"
    list_of_coordinates = Constants.DICT_OF_TRIANGLES['B']
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinates, "All pieces should be in the home cells"
        assert piece.get_color() == 'R', "All pieces should be R"

    player = Player('Albert')
    player.set_number_of_pieces(15)
    with pytest.raises(ValueError):
        player.set_home_cells("3"), "3 is suitable for default game, should raise ValueError"
    player.set_number_of_pieces(10)
    with pytest.raises(ValueError):
        player.set_home_cells("A"), "A is suitable for alternate game, should raise ValueError"


def test_get_target_triangle():
    player = Player('Russell')
    player.set_home_cells("3")
    assert player.get_target_triangle() == "6", "The target triangle should be 6"
    player.set_number_of_pieces(15)
    player.set_home_cells("B")
    assert player.get_target_triangle() == "A", "The target triangle should be A"


def test_get_home_triangle():
    player = Player('Russell')
    player.set_home_cells("3")
    assert player.get_home_triangle() == "3", "The home triangle should be 3"
    player.set_number_of_pieces(15)
    player.set_home_cells("B")
    assert player.get_home_triangle() == "B", "The home triangle should be B"


def test_set_pieces():
    player = Player("Alex")
    player.set_home_cells("3")
    player.set_color('P')
    list_of_coordinates = Constants.DICT_OF_TRIANGLES['3']
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinates, "All pieces should be in the home cells"
        assert piece.get_color() == 'P', "All pieces should be P"
        # checking the ability to reset player pieces
    player.set_color('R')
    player.set_number_of_pieces(15)
    player.set_home_cells("B")  # pay attention that set_pieces is called in every change
    list_of_coordinates = Constants.DICT_OF_TRIANGLES['B']
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinates, "All pieces should be in the home cells"
        assert piece.get_color() == 'R', "All pieces should be R"


def test_wins():  # testing the ability to track wins and the target sells.
    player = Player('dani')
    player.set_color('R')
    player.set_number_of_pieces(15)
    list_of_coordinate = Constants.DICT_OF_TRIANGLES['A']
    counter = 0
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinate, "All pieces should be in the home cells"
        assert piece.get_color() == 'R', "All pieces should be R"
        piece.move(Constants.DICT_OF_TRIANGLES['B'][counter])  # move pieces to target cells
        counter += 1

    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in Constants.DICT_OF_TRIANGLES['B'], "All pieces should be in the B cells"

    assert player.is_player_win() is True, "The player should win"
    assert player.get_score_of_player() == "Dani has 1 win and 0 losses", "The score of the player should be 1 - 0"

    player = Player('Chet')
    player.set_color('G')
    player.set_home_cells("5")
    list_of_coordinate = Constants.DICT_OF_TRIANGLES['5']
    counter = 0
    for piece in player.get_pieces_of_player():
        if counter > 8:  # only part of the pieces will get to the target
            break
        assert piece.get_coordinate() in list_of_coordinate, "All pieces should be in the home cells"
        assert piece.get_color() == 'G', "All pieces should be G"
        piece.move(Constants.DICT_OF_TRIANGLES['2'][counter])  # move pieces to target cells
        counter += 1
    assert player.is_player_win() is False, "The player should not win (only 8 of his pieces got the target)"
    player.increment_losses()
    assert player.get_score_of_player() == "Chet has 0 wins and 1 lose", "The score of the player should be 0 - 1"


def reset_for_next_match():
    player = Player('Victor')
    player.set_color('Y')
    player.set_number_of_pieces(15)
    list_of_coordinate = Constants.DICT_OF_TRIANGLES['A']
    counter = 0
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in list_of_coordinate, "All pieces should be in the home cells"
        assert piece.get_color() == 'R', "All pieces should be R"
        piece.move(Constants.DICT_OF_TRIANGLES['B'][counter])  # move pieces to target cells
        counter += 1
    assert player.get_score_of_player() == "Victor has 1 win", "The score of the player should be 1 win"
    # after winning, we reset the player for the next match (means his pieces will be in the home cells)
    player.reset_pieces_for_next_game()
    player.set_color("G")  # changing the color for the new game
    player.set_number_of_pieces(10)  # changing the number of pieces for the new game
    player.set_home_cells("3")  # changing the home cells for the new game
    for piece in player.get_pieces_of_player():
        assert piece.get_coordinate() in Constants.DICT_OF_TRIANGLES["3"], "All pieces should be in the new home cells"
        assert piece.get_color() == 'G', "All pieces should be G"
        assert len(player.get_pieces_of_player()) == 10, "The number of pieces should be 10"
