#############################################################
# FILE : constants.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: constants for chinese checkers project
#############################################################

class QuitGame:
    """
    Quit game return value. Will be used to quit the menu.
    """


class PreviousPage:
    """
    Previous page return value. Will be used to go back to the previous page.
    """


class Constants:
    """
    Constants for all files in the project.
    """
    # main.py constants:
    WELCOME_MSG = "Welcome to Chinese Checkers Main Menu!"
    WOULD_LIKE_TO_DO = "What would you like to do?"
    GAME_MENU = "Game Menu"
    TOURNAMENT_MODE = "2 - Tournament Mode"
    GAME_MODE = "1 - Game Mode"
    GAME_MODE_INPUT_RATE = "1"
    TOURNAMENT_MODE_INPUT_RATE = "2"
    DATA_MENU = "Data Menu"
    GET_PREVIOUS_DATA = "1 - Get previous data by inserting a Game ID"
    GET_PREVIOUS_DATA_INPUT_RATE = "1"
    START_NEW_GAME = "2 - Start a new game"
    START_NEW_GAME_INPUT_RATE = "2"
    CONTINUE_LOADED_GAME = "3 - Continue loaded game"
    CONTINUE_LOADED_GAME_INPUT_RATE = "3"
    DATA_GET_WINNER = "1 - Get winner of certain game by inserting a Game ID"
    DATA_GET_WINNER_INPUT_RATE = "1"
    DATA_GET_SINGLE_PLAYER = "2 - Get single player data by inserting Game ID"
    DATA_GET_SINGLE_PLAYER_INPUT_RATE = "2"
    DATA_GET_ENTIRE_DATA = "3 - Get entire data for certain game by inserting Game ID"
    DATA_GET_ENTIRE_DATA_INPUT_RATE = "3"
    DATA_GET_BOARD = "4 - Get the board of a certain game by inserting Game ID and round number"
    DATA_GET_BOARD_INPUT_RATE = "4"
    TOURNAMENT_MENU = "Tournament Menu"
    TOURNAMENT_DATA = "Tournament Data Menu"
    TOURNAMENT_EXPLANATION = ("Good Choice! Let's start a new tournament!"
                              "\nFirst, we need to set the tournament."
                              " You can set a tournament for either 4 - 12, with both human and computer"" players.\n"
                              "For computer players, you can choose between 3 different levels"
                              " of difficulty (LEVEL 3 available for 6 players in the semi final).\n"
                              "Tournament will have 3 games: Semi Finals and The"
                              " Final between both winners.""\nUnlike regular game, tournament can't be"
                              " saved and continued later.\nPick amount of players: ")
    NEW_TOURNAMENT = "1 - Start a new tournament"
    NEW_TOURNAMENT_INPUT_RATE = "1"
    GET_TOURNAMENT_DATA = "2 - Get previous data of tournament with tournament ID"
    GET_TOURNAMENT_DATA_INPUT_RATE = "2"
    GAME_ID = "Please insert a Game ID: "
    PLAYER_NAME = "Please insert a player name: "
    EXPLANATION_FOR_NEW_GAME = ("Good Choice! Let's start a new game!\nFirst, we need to set the game."
                                " You can set a game for either 2, 3, 4 or 6 players, with both human and computer"
                                " players.\nFor computer players, you can choose between 3 different levels"
                                " of difficulty (LEVEL 3 available for 6 players).\n Pick the number of players: ")
    EXPLANATION_FOR_COMPUTER_LEVEL = ("Set computer strategy:\n\nLEVEL 1 - The computer will make random moves.\n\n"
                                      "LEVEL 2 - The computer will try to make smart moves.\n")
    LEVEL_3_ADDITION = ("LEVEL 3 - The computer will try to make the smart\n"
                        " moves with unique disturbing"
                        " strategy \n(not necessarily more efficient but way more interesting).")
    SET_PLAYER_TYPE = "Please insert the type of player you want to set (HUMAN or COMPUTER): "
    SET_PLAYER_NAME = ("Please insert a one word player name\n"
                       "(for computer player - it must contain player Computer#rest_of_name.\n"
                       "You can't use Computer name for a human player.).\n"
                       "Start with capital letter.\n"
                       "Pay attention, you can't repeat a name twice: ")
    SET_PLAYER_COLOR = "Please pick a color: "
    DATA_FOR_USER_TITLE = "Data for "
    SUCCESSFUL_SETTING = "Player has been set successfully!\nLet's set the next player: "
    NEXT_PLAYER = "Next player:"
    TOURNAMENT_DATA_WINNER = "1 - Get winner of specific tournament"
    TOURNAMENT_DATA_ENTIRE = "2 - Get entire data of specific tournament"
    TOURNAMENT_DATA_WINNER_A = "3 - Get winner of Semi Final A"
    TOURNAMENT_DATA_WINNER_B = "4 - Get winner of Semi Final B"
    TOURNAMENT_DATA_SCORE = "5 - Get score of each participants in the tournament"
    TOURNAMENT_ID = "Please insert a Tournament ID (like 1712559397 - Tournament.log): "
    BOARD_AFTER_ROUNDS = "That's how the board looks like after the asked amount of rounds: "
    SINGLE_PLAYER_DATA = 1
    ENTIRE_GAME_DATA = 2
    OPTIONS_FOR_TYPE = ["1", "2"]
    OPTIONS_FOR_TYPE_WORDS = ["1 - HUMAN", "2 - COMPUTER"]
    OPTIONS_FOR_LEVEL = ["1", "2", "3"]
    OPTIONS_FOR_PLAYERS = ["2", "3", "4", "6"]
    TYPE_HUMAN = 1
    TYPE_COMPUTER = 2
    LEVEL_1 = 1
    LEVEL_2 = 2
    LEVEL_3 = 3
    NOT_ONE_WORD = " "
    EMPTY_STRING = ""

    # errors
    NO_WINNER = "There is no winner for this game."
    FILE_NOT_FOUND = "ID not found, try again"
    ERROR_WHILE_PROCESSING = "An error occurred while processing the data, try again"
    PLAYER_NOT_FOUND = "Player not found, try again"

    # other
    ONE = "1"
    TWO = "2"
    THREE = "3"
    FOUR = "4"
    SIX = "6"
    PREVIOUS_BOTTOM = "p"
    QUIT_BOTTOM = "q"
    GAME_TYPES = ["Regular Game", "Semi Final", "The Final"]
    LEN_LIST_OF_SET_PLAYERS = 4
    RANGE_OF_OPTIONS_DATA_TOURNAMENT = range(1, 6)

    DESCRIPTION = "How to use the program:\n\nWhen running python main.py, a GUI window presenting my project will" \
                  " open.\n\nThe user can choose between 2 options: Game Mode and Tournament Mode.\n" \
                  "In Game Mode, the user can start a new game, continue a loaded game or get previous data.\n" \
                  "In the Data Menu, the user can get the winner of a certain game, get single player data,"\
                  " get entire data for a certain game or get the board of a certain game"\
                  " (after inserting a game ID and round number).\nWhen user chooses to start a new game, he/she"\
                  " will be asked to set the game by choosing the number of players, the type of players"\
                  " (HUMAN or COMPUTER), the player name (depends on type of player), the player color and"\
                  " the computer level (all instructions will be shown as clear as possible on screen when setting.\n"\
                  "If the game is only computer players, the program will simulate the game.\n"\
                  "When one or more human players wants to play, the program will explain intuitively"\
                  " how to play the game. User may follow the instructions and play the game.\n"\
                  "By clicking on a valid piece, orange cells will appear (if piece invalid, a red message will"\
                  " inform user to choose another one). User may click on an orange cell in order"\
                  " to move the piece. After clicking the orange cell, piece will move and sound of the move"\
                  " will be applied. If user wants to choose another piece, he/she may click on Exit & Undo button,"\
                  " as simply shown on the screen, and then click on another one.\n"\
                  " to the cell. If the user wants to quit the game, he/she may click on Exit & Undo button.\n"\
                  "For other options, just follow the instructions on the screen.\n"\
                  "When quiting the game, the user will be asked if he/she wants to restart the game or quit.\n"\
                  "If the user chooses to quit, the game will be saved in a log file in the log_files directory.\n"\
                  "Else, data may be lost as shown on screen, and the game will be restarted"\
                  " (I implemented that way since that is what I know from video games, and I think it's more user"\
                  " friendly).\nIf player wants to continue a loaded game, he/she will be asked to insert a log"\
                  " file, and immediately continue the game with the last player who quit (using the log files).\n"\
                  "For your convenient, you should get some tournament and game id from log_files directory,"\
                  " which keeps all the log files.\n\n" \
                  "In Tournament Mode, the user can start a new tournament or get previous data of a tournament.\n" \
                  "User can set a new tournament by choosing the number of players"\
                  " and just follow the intuitive instructions on the screen.\n"\
                  "If the user chooses to get previous data of a tournament, he/she will be asked to insert a"\
                  " tournament ID and choose between 5 options to get the data (do not get confused with game id)"\
                  " (unlike game mode, tournament cant be loaded and be continued).\n\n"\
                  "Enjoy the game and have fun!\n"

    # tournament.py constants:
    MIN_NUM_OF_PLAYERS = 4
    MAX_NUM_OF_PLAYERS = 12
    SEMI_DIVIDER = 2
    TWO_AS_INT = 2
    TOTAL_NUMBER_OF_PLAYERS_MESSAGE = "Number of players in tournament is: "
    NUM_OF_PLAYERS_FOR_SEMI_A_MESSAGE = "Number of players for semi-final A: "
    NUM_OF_PLAYERS_FOR_SEMI_B_MESSAGE = "Number of players for semi-final B: "
    SETTING_PLAYERS_FOR_SEMI = "Setting players for "
    PARTICIPANTS_ARE = "The participants of current semi-final are: "
    GETTING_DATA_OF_GAME_BY_GAME_ID = "If you wish so, you should get data of game by game id: "
    PREPARE_FOR_THE_BIG_FINAL = "Prepare for the big Final!"
    GET_STARTED_WITH_TOURNAMENT = ("Let's get started with the tournament!\n\n"
                                   "If you wish to load data of the tournament in the future, keep the following id: ")
    SEMI_FINAL_A = "Semi-Final A"
    SEMI_FINAL_B = "Semi-Final B"
    FINAL = "The Final"
    FINAL_COLORS = ["R", "B"]
    COLORS_MESSAGE = ("Pay attention that the colors of the players are changed due to the big final!"
                      "\nWinner of semi-final A will be RED and winner of semi-final B will be BLUE.")
    QUITTING_TO_MENU = "Leaving the tournament... Going back to menu."
    QUITTING_TO_NUM_OF_PLAYERS = "Leaving the tournament... Going back to number of players question."
    SCORE_LOGGER = "#FINAL_SCORE:"
    STOP_LOGGING = " Stop logging tournament..."
    PRESS_HERE_TO_CONTINUE = "press here to continue (if you want to quit, press Exit & Undo)."
    INVALID_NUM_OF_PLAYERS = "Invalid number of players - "

    # loader_menu.py constants:

    # inline constants representing the index of the data in line in the log file
    WINNER_INDEX = 6
    PLAYER_INDEX = 7
    PIECE_INDEX = 9
    CELL_INDEX = 11  # remember we replace the space after the comma with nothing in order to get one word

    # inline constants representing number of line of data in the log file
    LINE_OF_DATA = 2

    # inline constants representing the index of the data in dict data from the log file
    COLOR_INDEX = 1
    NUMBER_OF_PIECES_INDEX = 2
    HOME_CELLS_INDEX = 3
    STRATEGY_INDEX = 4
    GAME_TYPE_INDEX = 5

    RELATIVE_PATH = "./log_files/"  # the relative path to the log files directory

    # inline constants representing the error messages
    INVALID_DATA_ERROR = "Invalid data for player "
    NO_MOVES_ERROR = "No moves found for player "
    CANT_CONTINUE_ERROR = "Cannot continue with current ID (probably there is a winner or unsuitable ID)."

    # inline constants representing messages for the user
    INSERT_LOG_FILE = "Please insert a log file path (like: 1710964961 - Regular Game.log)."

    # others
    FIND_DATA_DICT = "The data for the next use is: "
    FIND_ROUND_INFO = "The game has been quit by the user in round "
    FIND_WHO_QUIT = "over!!!,"
    FIND_WINNER = "is the winner"
    FIND_ROUND_MESSAGE = "Please insert the round number you want to watch in game ID "
    REMOVE_LOG_INDEX = -4
    ROUND_INDEX = 2
    PREVIOUS_PAGE_CHAR = 'p'
    QUIT_CHAR = 'q'

    # options for tournament data
    OPTION_FOR_TOURNAMENT_DATA_WINNER = 1
    OPTION_FOR_TOURNAMENT_DATA_ALL_DATA = 2
    OPTION_FOR_TOURNAMENT_DATA_WINNER_A = 3
    OPTION_FOR_TOURNAMENT_DATA_WINNER_B = 4
    OPTION_FOR_TOURNAMENT_DATA_SCORE = 5
    FIND_TOURNAMENT_WINNER = "The Final winner is: "
    TOURNAMENT_WINNER_INDEX = -1
    NO_WINNER_OF_TOURNAMENT = "No winner found for tournament ID "
    FIND_SEMI_A_WINNER = "Semi-Final A winner is: "
    FIND_SEMI_B_WINNER = "Semi-Final B winner is: "
    NO_SEMI_WINNER = "No winner found for semi-final "
    TOURNAMENT_SCORE_SLICE_MIN = -7
    TOURNAMENT_SCORE_SLICE_MAX = 0
    NO_SCORE_FOUND = "No score found for tournament ID "
    WINNER_OF = "The winner of "
    INVALID_OPTION = "Invalid option for data."
    TOURNAMENT = "Tournament"

    # game.py constants:

    OPTIONS_FOR_GAME = [2, 3, 4, 6]  # the options for the number of players
    COLORS_IN_GAME = ["R", "Y", "B", "P", "G", "W"]  # the colors in the game
    COMPUTER_NAME = "Computer"  # every computer players must star with this name
    STRATEGY_LEVELS = [1, 2, 3]  # the levels of the strategies: 1 - random, 2 - best move, 3 - master
    TARGET_TRIANGLE_FOR_NUM_OF_PLAYERS = {2: ["A", "B"], 3: ["4", "6", "2"],
                                          4: ["2", "3", "5", "6"], 6: ["1", "2", "3", "4", "5", "6"]}
    HOME_TRIANGLE_FOR_NUM_OF_PLAYERS = {2: ["A", "B"], 3: ["1", "3", "5"], 4: ["2", "3", "5", "6"],
                                        6: ["1", "2", "3", "4", "5", "6"]}
    # the target\home triangle for each number of players
    OPTIONS_FOR_ID = ["Semi-Final A", "Semi-Final B", "The Final", "Regular Game"]  # the options for the game type
    EXAMPLE_OF_CELL = (1, 2)

    # messages for the user
    GAME_OVER = "The game is over!!!"
    RESTART_GAME = "Do you want to restart the game?"
    WELCOME_MESSAGE = "Welcome to Chinese Checkers "
    GAME_ID_MESSAGE = "Keep Game ID for future use: "
    YES = "y"
    NO = "n"
    ZERO = 0
    ONE_AS_INT = 1
    QUIT_GAME = "q"
    OTHER_PIECE = "o"
    ENDED_AFTER = "The game has ended after "
    START_PARTICIPANTS = "The game has started! The participants are: "
    SAVE_GAME_MESSAGE = "If yow wish to load the game in the future, game has been saved in a log file "
    LOAD_GAME_MESSAGE = "Do you want to load previous or current game moves? (y for YES. Otherwise - press anything): "
    MOVE_INFO = "Move Info: "
    QUIT_IN_ROUND = "The game has been quit by the user in round "
    LOADED_CONTINUE = "has been loaded, let's continue with the player who quit last time!"
    LOST_DATA_RESTART = ("Pay attention! If you restart the game,"
                         " the current game data won't be loaded (If you quit - all data will be loaded to log file)")
    SIMULATE_GAME = "Simulating the game for the computers"
    LOG_FILE_PATH = "./log_files"  # the path for the log files
    PICK_PIECE = "Please pick a piece to move by clicking on it. If you want to quit the game, press Exit & Undo."
    PICK_CELL = ("Please pick a cell to move the piece to by clicking on it (orange cells are possible moves)."
                 "\nIf you want to choose another piece, press Exit & Undo.")
    SIMULATED_ENDED = "Simulated game has stopped after "
    DATA_FOR_NEXT_USE = "The data for the next use is: "
    SAVED_IN_LOG = "(will be saved in a log_files directory)."
    # error messages
    INVALID_INPUT = "Invalid input, try again!"
    INVALID_PIECE = "Invalid piece, try again!"
    INVALID_CELL = "Invalid cell, try again!"
    ERROR_GAME_TYPE = "The game type should be one of the following: Semi-Final, Final, Regular Game"
    ERROR_ADD_PIECE = "An error occurred while adding the pieces to the board"
    CANNOT_MOVE = "This piece cannot move anywhere, please choose another piece."
    PARTICIPANTS_ERROR = "The number of participants should be 2, 3, 4 or 6"
    COLOR_ERROR = "The color of the player should be one of the following: R, Y, B, P, G, W"
    STRATEGY_ERROR = "The strategy level should be 1, 2 or 3"
    NONE_FOR_HUMAN_ERROR = "The strategy should be None for human players"
    COMPUTER_NAME_ERROR = "Computer players must have a computer name"
    NUM_OF_PIECES_ERROR = "The number of pieces for each player should be 10 for 3, 4, 6 players or 15 for 2 players"
    TARGET_TRIANGLE_ERROR = "The target triangle for each player should be one of the following: "
    PIECES_IN_HOME_CELLS_ERROR = "All the pieces of the player should be in the home cells"
    SAME_HOME_CELLS_ERROR = "Each player must have different home cells for their pieces"
    FILE_NOT_FOUND_ERROR = "No log file found for ID "
    ERROR_COLOR = "red"
    LOGGER_FORMAT = "%(asctime)s - %(name)s  - %(message)s"
    ROUND_LIMIT_FOR_SIMULATIONS = 800  # the limit for the rounds in the simulations (avoiding infinite loop)

    # sound
    MOVE_SOUND = "./sounds/moving_piece.mp3"

    # gui_main.py constants:

    # strings for the GUI
    TITLE = "Chinese Checkers Application"
    QUIT = "Quit"
    PREVIOUS = "Previous Page"
    PREVIOUS_FOR_SETTING_NUM_OF_PLAYERS = "Previous Page (Setting Number of Players)"
    PREVIOUS_CHAR = "p"
    INVALID = "Invalid input, try again"
    ERROR = "Error!"

    # gui colors and design
    ROOT_GEOMETRY = "zoomed"
    FONT_OF_INIT_LABEL = ("Helvetica", 14, "bold")
    FONT_OF_BUTTON = ("Helvetica", 12, "bold")
    FONT_OF_INSERT_ENTRY = ("Helvetica", 12, "bold")
    COLOR_OF_BACKGROUND_LABEL = "blue"
    COLOR_OF_EXTRA_BACKGROUND_LABEL = "green"
    COLOR_OF_TEXT_LABEL = "white"
    COLOR_OF_BUTTON = "orange"
    COLOR_OF_QUIT_BUTTON = "red"
    COLOR_OF_PREVIOUS_BUTTON = "grey"
    INSERTION_COLOR = "orange"
    INSERT_HERE = "insert here"
    WIDTH_OF_ENTRY = 50
    CONFIRM = "Confirm"
    COLOR_OF_CONFIRM_BUTTON = "white"
    COLOR_OF_CONFIRM_TEXT = "orange"
    FONT_OF_CONFIRM_BUTTON = ("Helvetica", 12, "bold")
    COLOR_OF_ERROR_MESSAGE = "red"

    # for tournament button
    TEN_TO_TWELVE_LIST = ["10", "11", "12"]

    # more
    REFACTOR_X_BUTTON = "WM_DELETE_WINDOW"

    # for the board
    COLOR_MAP = {
        'R': 'red',
        'Y': 'yellow',
        'B': 'blue',
        'P': 'purple',
        'G': 'green',
        'W': 'white'
    }

    NONE_COLOR = 'grey'
    UNIDENTIFIED_COLOR_CODE = 'W'
    COL_OFFSET = 30
    ROW_OFFSET = 50
    EXTRA_PADDING = 20
    RADIUS = 10.5
    SPACE = 7
    PADDING = 10
    WIDTH_OF_CIRCLE_ID = 1
    FONT = ("Helvetica", 6, "bold")
    OUT_OF_BOARD_COLOR = 'white'
    OUT_OF_BOARD_OUTLINE = 'white'
    PRESSING_MOUSE = '<Button-1>'
    DELETE_PREV_CANVAS = 'all'
    POSSIBLE_MOVES_COLOR = 'orange'
    OUTLINE_COLOR = 'black'
    COLOR_OF_BACKGROUND_FOR_BOARD = "orange"
    EXIT_UNDO = "Exit & Undo"
    COLOR_OF_BACKGROUND_EXIT_UNDO = "red"
    FONT_OF_EXIT_UNDO = ("Helvetica", 10, "bold")
    EXIT_WIDTH = 9
    EXIT_HEIGHT = 5
    EXIT_PADX = 10
    FONT_OF_TURN_LABEL = ("Helvetica", 12, "bold")
    FONT_OF_LABEL_SMALL = ("Helvetica", 9, "bold")
    DARK_COLOR = ["blue", "red", "green", "purple"]

    # strategy.py constants:

    # grades for the best move
    GRADE_A = 5
    GRADE_B = 4
    GRADE_C = 3
    GRADE_D = 2
    GRADE_E = 1

    # the difference in rows for the best move
    BIG_JUMP = 6
    MEDIUM_JUMP = 4
    SMALL_JUMP = 2
    SIMPLE_STEP_FORWARD = 1

    # direction_of_attack
    UP = "up"
    DOWN = "down"
    UP_LEFT = "ul"
    UP_RIGHT = "ur"
    DOWN_LEFT = "dl"
    DOWN_RIGHT = "dr"

    # for best_strategy
    INNER_CELL_A = (0, 6)  # the inner cell of the home triangle A
    INNER_CELL_B = (16, 6)  # the inner cell of the home triangle B

    # aim height for the best move. The aim height is the row number of the average cell in the target triangle.
    AIM_HEIGHT_FOR_TARGET_5 = 10.5  # the average height of the target triangle 5 (when home cell is 2)
    AIM_HEIGHT_FOR_TARGET_6 = 5.5  # the average height of the target triangle 6 (when home cell is 3)
    AIM_HEIGHT_FOR_TARGET_2 = 5.5  # the average height of the target triangle 2 (when home cell is 5)
    AIM_HEIGHT_FOR_TARGET_3 = 10.5  # the average height of the target triangle 3 (when home cell is 6)
    CLOSE_TO_TARGET_RATE = 1.5  # the distance from the aim height which is considered close to the target (vertically)

    # for master strategy - disturb the opponent
    CELL_TO_DISTURB_1 = [(3, 5), (3, 6), (3, 7), (3, 8)]
    CELL_TO_DISTURB_2 = [(4, 9), (5, 10), (6, 10), (7, 11)]
    CELL_TO_DISTURB_3 = [(9, 11), (10, 10), (11, 10), (10, 9)]
    CELL_TO_DISTURB_4 = [(13, 5), (13, 6), (13, 7), (13, 8)]
    CELL_TO_DISTURB_5 = [(9, 2), (10, 2), (11, 3), (12, 3)]
    CELL_TO_DISTURB_6 = [(4, 3), (5, 3), (6, 2), (7, 2)]
    LIST_OF_CELLS_TO_DISTURB = [CELL_TO_DISTURB_1, CELL_TO_DISTURB_2, CELL_TO_DISTURB_3, CELL_TO_DISTURB_4,
                                CELL_TO_DISTURB_5, CELL_TO_DISTURB_6]

    # for master strategy - extra stables
    RATE_OF_DISTURB = 5  # means in average once in 5 moves the method will call a piece to disturb
    NUM_OF_TRIES_FOR_BEST_MOVE = 20  # number of tries to find a move without disturb pieces

    # player.py constants:

    DEFAULT_COLOR = "W"  # the default color for every player
    DEFAULT_NUMBER_OF_PIECES = 10  # the default number of pieces for every player
    ALTERNATE_NUMBER_OF_PIECES = 15  # the alternate number of pieces for every player - usually in one vs one game
    DICT_OF_TRIANGLES: dict[str, list[tuple[int, int]]] = {"1": [(0, 6), (1, 6), (1, 7), (2, 5), (2, 6),
                                                                 (2, 7), (3, 5), (3, 6), (3, 7), (3, 8)],
                                                           "2": [(4, 9), (4, 10), (4, 11), (4, 12),
                                                                 (5, 10), (5, 11), (5, 12), (6, 10),
                                                                 (6, 11), (7, 11)],
                                                           "3": [(9, 11), (10, 10), (10, 11), (11, 10),
                                                                 (11, 11), (11, 12), (12, 9), (12, 10),
                                                                 (12, 11), (12, 12)],
                                                           "4": [(16, 6), (15, 6), (15, 7), (14, 5),
                                                                 (14, 6), (14, 7), (13, 5), (13, 6), (13, 7), (13, 8)],
                                                           "5": [(9, 2), (10, 1), (10, 2), (11, 1),
                                                                 (11, 2), (11, 3), (12, 0), (12, 1),
                                                                 (12, 2), (12, 3)],
                                                           "6": [(4, 0), (4, 1), (4, 2), (4, 3), (5, 1),
                                                                 (5, 2), (5, 3), (6, 1), (6, 2), (7, 2)],
                                                           "A": [(0, 6), (1, 6), (1, 7), (2, 5), (2, 6),
                                                                 (2, 7), (3, 5), (3, 6), (3, 7), (3, 8),
                                                                 (4, 4), (4, 5), (4, 6), (4, 7), (4, 8)],
                                                           "B": [(16, 6), (15, 6), (15, 7), (14, 5),
                                                                 (14, 6), (14, 7), (13, 5), (13, 6), (13, 7), (13, 8),
                                                                 (12, 4), (12, 5), (12, 6), (12, 7), (12, 8)]}
    # the triangles 1 - 6 is the triangles for multi - game, and A - B is the triangles for one vs one game
    OPPOSITE_TRIANGLE_KEY = 3  # the key of the opposite triangle in the dictionary (+3 or -3; like 1 - 4, 5 - 2)
    INIT_NUM_OF_WINS = 0  # the default number of wins for every player
    INIT_NUM_OF_LOSES = 0  # the default number of loses for every player

    # errors
    ILLEGAL_NAME = "Illegal name. Please enter a valid name (like Bob). Player Error."
    ILLEGAL_COLOR = "Illegal color. Please enter a valid color (like Y for yellow). Player Error."
    ILLEGAL_NUM_OF_PIECES = "Illegal number of pieces. Please enter a valid number of pieces (10 or 15). Player Error."
    ILLEGAL_HOME_CELLS = "Illegal home cells. Please enter a valid home cells (like 1 or A). Player Error."
    PAY_ATTENTION_HOME_CELLS = "Illegal home cells. Pay attention if default (1-6) or alternate (A-B)."
    NAME_FIRST_CHAR = "name first char must be a letter. Player Error."
    NAME_ONE_WORD = "name must be one word. Player Error."

    # board.py constants:

    # constants for the board size
    ENTIRE_BOARD_LENGTH = 17
    ENTIRE_BOARD_WIDTH = 14
    TOP_TRIANGLE_SIZE = 5
    TOP_HALF_BODY_SIZE_START = 13
    TOP_HALF_BODY_SIZE_END = 8
    BOTTOM_HALF_BODY_SIZE_START = 10
    BOTTOM_HALF_BODY_SIZE_END = 14
    BOTTOM_TRIANGLE_SIZE = 5

    SIMPLE_STEP = "simple step"
    HOP_OVER_ANOTHER_PIECE = "hop over another piece"

    # errors
    COORDINATE_NOT_ON_BOARD = "The coordinate of the piece is not on the board. Board Error."
    PIECE_ALREADY_ON_BOARD = "The piece is already on the board. Board Error."
    OCCUPIED_CELL = "The cell is already occupied. Board Error."
    ILLEGAL_MOVE = "The move is not legal. Board Error."

    # piece.py constants:

    LEGAL_COLOR_LENGTH = 1
    MIN_NUMBER = 1
    LENGTH_OF_COORDINATE = 2
    DOUBLE_DIGIT_NUMBER = 10
    ZERO_STRING = '0'
    POSSIBLE_MOVES = ["simple step", "hop over another piece"]
    # error messages
    ILLEGAL_COLOR_FOR_PIECE = "Illegal color. Please enter a valid color (like Y for yellow). Piece Error."
    ILLEGAL_NUMBER = "Illegal number. Please enter a valid number (like 1 or higher). Piece Error"
    ILLEGAL_COORDINATE = "Illegal coordinate. Please enter a valid coordinate (like (0, 0)). Piece Error."
