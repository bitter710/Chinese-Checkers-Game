#############################################################
# FILE : test_for_final_project_piece.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: test for piece class for chinese checkers game
#############################################################

import pytest
from piece import Piece


def test_get_name():
    piece = Piece('Y', 1, (0, 0))  # creating a piece for testing
    assert piece.get_name() == 'Y01', 'The name of the piece should be Y01'
    piece = Piece('M', 7, (8, 0))
    assert piece.get_name() == 'M07', 'The name of the piece should be M07'
    piece = Piece('R', 3, (0, 0))
    assert piece.get_name() == 'R03', 'The name of the piece should be R03'


def test_get_coordinate():
    piece = Piece('Y', 1, (0, 0))
    assert piece.get_coordinate() == (0, 0), 'The coordinate of the piece should be (0, 0)'
    piece = Piece('M', 7, (8, 0))
    assert piece.get_coordinate() == (8, 0), 'The coordinate of the piece should be (8, 0)'
    piece = Piece('R', 3, (819, 15767))
    assert piece.get_coordinate() == (819, 15767), 'The coordinate of the piece should be (819, 15767)'


def test_get_color():
    piece = Piece('Y', 1, (0, 0))
    assert piece.get_color() == 'Y', 'The color of the piece should be Y'
    piece = Piece('M', 7, (8, 0))
    assert piece.get_color() == 'M', 'The color of the piece should be M'
    piece = Piece('R', 3, (819, 15767))
    assert piece.get_color() == 'R', 'The color of the piece should be R'


def test_illegal_color():
    with pytest.raises(ValueError):
        Piece('y', 1, (0, 0))  # lowercase color should raise ValueError
    with pytest.raises(ValueError):
        Piece('Yellow', 1, (0, 0))  # long color should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y1', 1, (0, 0))  # full name in color should raise ValueError
    with pytest.raises(ValueError):
        Piece('1', 1, (0, 0))  # number in color should raise ValueError


def test_illegal_number():
    with pytest.raises(ValueError):
        Piece('Y', 0, (0, 0))  # number less than 1 should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', -1, (0, 0))  # negative number should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 2.3, (0, 0))  # float number should raise ValueError


def test_illegal_coordinate():
    with pytest.raises(ValueError):
        Piece('Y', 1, (0))
    # coordination with less or more than 2 elements should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (0, -1))  # negative coordinate should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (-1, 0))  # negative coordinate should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (0, 0.5))  # float coordinate should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (0, '0'))  # string coordinate should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (0, [0]))  # list coordinate should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (0, (0, 0)))  # tuple coordinate should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, (0, 3, 0))
    # coordination with less or more than 2 elements should raise ValueError
    with pytest.raises(ValueError):
        Piece('Y', 1, [0, 0])  # coordination as list should raise ValueError


def test_move():
    piece = Piece('Y', 1, (0, 0))
    assert piece.move((0, 1)) is True, ('The move should be successful.'
                                        ' The piece can move everywhere as long as the coordinate is valid')
    assert piece.get_coordinate() == (0, 1), 'The coordinate of the piece should be (0, 1)'
    assert piece.move((1, 1)) is True, ('The move should be successful.'
                                        ' The piece can move everywhere as long as the coordinate is valid')
    assert piece.get_coordinate() == (1, 1), 'The coordinate of the piece should be (1, 1)'
    assert piece.move((1, -1)) is False, 'The move should be unsuccessful. The coordinate is invalid'
    assert piece.get_coordinate() == (1, 1), 'The coordinate of the piece should still be (1, 1)'
    assert piece.move((1, 1.5)) is False, 'The move should be unsuccessful. The coordinate is invalid'
    assert piece.get_coordinate() == (1, 1), 'The coordinate of the piece should still be (1, 1)'
