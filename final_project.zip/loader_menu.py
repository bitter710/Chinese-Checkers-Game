#############################################################
# FILE : loader_menu.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: loader_menu class for final project
#############################################################
from game import *
from constants import *
import ast
from typing import Any, Optional


class CantContinue(Exception):
    """
    Quit game exception. Will be used to quit the menu.
    """


class LoaderMenu:

    """
    LoaderMenu class for final project. This class is responsible for loading a game from a log file.
    User has two main options: get the data from the log file (for certain player, for everyone or get the winner)
    or continue the game right where it stopped by diving the game ID.
    You can get data from a tournament log file as well.
    All the log files are stored in the log_files folder.
    """

    @staticmethod
    def load_game_data(game_id: str, player_name: Optional[str]) -> str:
        """
        A method for loading a previous game.
        """
        try:
            if Constants.TOURNAMENT in game_id:  # if the game_id is a tournament
                raise FileNotFoundError
            with open(f'{Constants.RELATIVE_PATH}{game_id}', 'r') as log_file:
                log_lines = log_file.readlines()
                if player_name is None:  # if no player_name is provided, return all lines
                    return '\n'.join(log_lines)
                else:  # if a player_name is provided, filter the lines
                    dict_of_players = LoaderMenu.__get_a_dict_from_file(game_id)
                    for key in dict_of_players.keys():
                        if key == player_name:  # for the player_name provided
                            player_turns = [line for line in log_lines if player_name in line]
                            return '\n'.join(player_turns)
                    return f"{Constants.NO_MOVES_ERROR}{player_name} in game ID {game_id}."  # means player not found
        except FileNotFoundError:
            raise FileNotFoundError(f"{Constants.FILE_NOT_FOUND_ERROR}{game_id}.")

    @staticmethod
    def load_game_winner(game_id: str) -> Any:
        """
        A method for loading the winner of a certain game.
        """
        try:
            if Constants.TOURNAMENT in game_id:  # if the game_id is a tournament
                raise FileNotFoundError
            with open(f'{Constants.RELATIVE_PATH}{game_id}', 'r') as log_file:
                log_lines = log_file.readlines()
                for line in log_lines:
                    if Constants.FIND_WINNER in line:  # if the line contains the winner
                        new_line = line.split()
                        winner_name = new_line[Constants.WINNER_INDEX]
                        return winner_name
                return False  # if no winner was found
        except FileNotFoundError:
            raise FileNotFoundError(f"{Constants.FILE_NOT_FOUND_ERROR}{game_id}.")

    @staticmethod
    def continue_game(main_root: GUIMain, just_watch_board_situation: Optional[bool]) -> Any:
        """
        A method for continuing a game. Returns a game object or a board object. Can be used twice: If user wants to
        continue the game, or if user wants to watch the board situation (more efficient code, using similar functions).
        """
        flag_of_valid_input = True  # a flag for valid input
        reload_board = None  # a variable for the board
        valid_dict_for_game: dict = {}  # a dictionary for the game
        game_type = ""  # a variable for the game type
        while True:  # For GUI - reset the value of the button, update the message label, add insertion option,
            # update the buttons and start mainloop
            main_root.reset_button_value()
            main_root.update_message(Constants.INSERT_LOG_FILE)
            main_root.add_insertion_option(flag_of_valid_input)
            main_root.update_button_in_gui([Constants.PREVIOUS])
            main_root.start_main_loop()
            game_id = main_root.get_button_value()  # get the game_id from the user
            try:
                if game_id == Constants.PREVIOUS_PAGE_CHAR or game_id == Constants.EMPTY_STRING:
                    raise Quit  # if the user wants to quit
                if Constants.TOURNAMENT in game_id:  # if the game_id is a tournament
                    raise CantContinue(Constants.CANT_CONTINUE_ERROR)
                dict_of_data = LoaderMenu.__get_a_dict_from_file(game_id)  # convert the file data to a dictionary
                valid_dict_for_game, game_type = LoaderMenu.__convert_data_dict_into_valid_dict_for_game(dict_of_data)
                # convert the dictionary to a valid dictionary and game type for the game via a helper method
                init_board = LoaderMenu.__board_init(valid_dict_for_game)  # initialize the board via a helper method
                if just_watch_board_situation is True:  # if the user just wants to watch the board situation
                    main_root.remove_extra_message_label()  # remove the extra message label
                    find_round_limit: str = LoaderMenu.__get_round_number_for_board_display(main_root, game_id)
                    # get the round string to find
                    reload_board_to_watch = (LoaderMenu.__board_reload
                                             (init_board, valid_dict_for_game, game_id, find_round_limit))
                    main_root.remove_insertion_option()
                    return reload_board_to_watch
                reload_board = LoaderMenu.__board_reload(init_board, valid_dict_for_game, game_id)
                # reload the board via a helper method
                with open(f'{Constants.RELATIVE_PATH}{game_id}', 'r') as log_file:
                    log_lines = log_file.readlines()
                    log_lines.reverse()
                    # reverse the lines. This is because sometimes the game is loaded several times,
                    # and I want to get the last data
                    found_round_info = False  # a flag for finding the round info - game can be continued
                    for line in log_lines:
                        if Constants.FIND_ROUND_INFO in line:  # if the line contains the data dictionary
                            line = line[::-1]  # reverse the line
                            loaded_round_number = int(line[Constants.ROUND_INDEX])  # taking the second last character
                            found_round_info = True  # game can be continued
                            break
                    if not found_round_info:  # if game cannot be continued
                        raise CantContinue(Constants.CANT_CONTINUE_ERROR)
                    for line in log_lines:
                        if Constants.FIND_WHO_QUIT in line:
                            words = line.split()
                            over_index = words.index(Constants.FIND_WHO_QUIT)
                            player_to_continue = words[over_index + 1]
                            break
                    break  # if everything is ok, break the loop
            except FileNotFoundError:
                flag_of_valid_input = False  # if the file is not found, set the flag to False
                main_root.add_extra_message_label(f"{Constants.FILE_NOT_FOUND_ERROR}.", Constants.ERROR_COLOR)
                main_root.remove_insertion_option()
                continue
            except Quit:  # if the user wants to quit
                main_root.remove_insertion_option()
                main_root.remove_extra_message_label()
                raise Quit
            except CantContinue:  # if there is a general exception (probably there is a winner), raise it
                flag_of_valid_input = False  # if there is an exception, set the flag to False
                main_root.add_extra_message_label(Constants.CANT_CONTINUE_ERROR, Constants.ERROR_COLOR)
                main_root.remove_insertion_option()
                continue
            except Exception as e:
                flag_of_valid_input = False  # if there is an exception, set the flag to False
                main_root.show_error(str(e))
                main_root.remove_insertion_option()
        # now we finally have the dict, board and the round number, so we can continue the game
        game_id = game_id[:Constants.REMOVE_LOG_INDEX]  # remove the ".log" from the game_id
        main_root.reset_widgets()  # reset the widgets
        continue_game = Game(main_root, valid_dict_for_game, game_type,
                             True, reload_board, loaded_round_number, game_id, player_to_continue)
        main_root.remove_insertion_option()
        return continue_game

    @staticmethod
    def __get_a_dict_from_file(game_id: str) -> dict[str, Any]:
        """
        A method for getting a line from a file.
        """
        try:
            with open(f'{Constants.RELATIVE_PATH}{game_id}', 'r') as log_file:
                log_lines = log_file.readlines()
                log_lines.reverse()
                # reverse the lines. This is because sometimes the game is loaded several times,
                # and I want to get the last data
                for line in log_lines:
                    if Constants.FIND_DATA_DICT in line:  # if the line contains the data dictionary
                        dict_string = line.split(Constants.FIND_DATA_DICT)[1]
                        data_dict = ast.literal_eval(dict_string)  # convert the string to a dictionary
                        if isinstance(data_dict, dict):  # if the dictionary is not empty
                            return data_dict
                else:
                    raise ValueError(f"The file {game_id} is empty.")
        except FileNotFoundError:
            raise FileNotFoundError(f"{Constants.FILE_NOT_FOUND_ERROR}{game_id}.")
        except ValueError:
            raise ValueError(f"The file {game_id} is empty.")

    @staticmethod
    def __convert_data_dict_into_valid_dict_for_game(data_dict: dict[str, Any]) -> tuple[dict[Player, Any], str]:
        """
        A method for converting a dictionary into a valid dictionary for the game.
        Returns a tuple of dictionary and game type
        """
        valid_dict_for_game = {}  # the dictionary that will be returned, and sent to game
        game_type = ""
        for key, value in data_dict.items():  # iterating over the dictionary
            try:
                new_player = Player(key)  # create a new player and setting its attributes
                new_player.set_color(value[Constants.COLOR_INDEX])
                new_player.set_number_of_pieces(value[Constants.NUMBER_OF_PIECES_INDEX])
                new_player.set_home_cells(value[Constants.HOME_CELLS_INDEX])
                valid_dict_for_game[new_player] = value[Constants.STRATEGY_INDEX]  # add the player to the dictionary
                game_type = value[Constants.GAME_TYPE_INDEX]  # set the game type
            except ValueError:
                raise ValueError(f"{Constants.INVALID_DATA_ERROR}{key}.")
            except Exception as e:  # if there is a general exception in player creation, raise it
                raise Exception(e)
        return valid_dict_for_game, game_type  # return the dictionary and game type

    @staticmethod
    def __board_init(valid_dict_for_game: dict[Player, Any]) -> Board:
        """
        A method for initializing the board.
        """
        renewed_board = Board()  # create a new board
        for player_to_add in valid_dict_for_game.keys():  # iterate over the players
            for piece_to_add in player_to_add.get_pieces_of_player():  # iterate over the pieces of the players
                try:
                    renewed_board.add_piece_to_board(piece_to_add)  # add the pieces of the players to the board
                except ValueError:
                    raise ValueError(Constants.ERROR_ADD_PIECE)
                except Exception as e:  # if there is a general exception in initializing the board, raise it
                    raise Exception(e)
        return renewed_board  # return the renewed board (before loading the moves)

    @staticmethod
    def __board_reload(init_board: Board, valid_dict_for_game: dict[Player, Any], game_id: str,
                       find_round_limit_str: Optional[str] = None) -> Board:
        """
        A method for reloading the board.
        """
        loading_board = init_board  # load the board
        try:
            with open(f'{Constants.RELATIVE_PATH}{game_id}', 'r') as log_file:  # open the file
                log_lines = log_file.readlines()
                for line in log_lines:  # iterate over the lines of the file
                    if find_round_limit_str and find_round_limit_str in line:
                        # if user wanted only to watch the board situation (and we reached the round)
                        return loading_board  # return the board after loading the moves till the round
                    if Constants.MOVE_INFO in line:  # if the line contains move info
                        player_name, piece_name, new_cell = LoaderMenu.__extract_move_info(line)
                        # call a helper method to extract the move info
                        for player_to_check in valid_dict_for_game.keys():  # iterate over the players
                            if player_to_check.get_name() == player_name:  # if the player name matches
                                for piece_to_check in player_to_check.get_pieces_of_player():  # iterate over the pieces
                                    if piece_to_check.get_name() == piece_name:  # if the piece name matches
                                        loading_board.move_piece(piece_to_check, new_cell)  # move the piece new cell
                return loading_board  # return the board after loading the moves
        except FileNotFoundError:
            raise FileNotFoundError(f"{Constants.FILE_NOT_FOUND_ERROR}{game_id}.")
        except Exception as e:  # if there is a general exception in reloading the board, raise it
            raise Exception(e)

    @staticmethod
    def __extract_move_info(line: str) -> tuple[str, str, tuple[int, int]]:
        """
        A method for extracting the move info from a line.
        """
        line = line.replace(", ", ",")  # replace the space after the comma with nothing
        parts = line.split()
        player_name = parts[Constants.PLAYER_INDEX]  # extract the player name
        piece_name = parts[Constants.PIECE_INDEX]  # extract the piece name
        new_cell = parts[Constants.CELL_INDEX]  # extract the new cell in string format
        new_cell = new_cell.strip("()")  # remove the parentheses
        row, col = map(int, new_cell.split(","))  # split on the comma and convert to two integers (will be tuple)
        return player_name, piece_name, (row, col)

    @staticmethod
    def __get_round_number_for_board_display(main_root: GUIMain, game_id: str) -> str:
        """
        A method for getting the round number for displaying the board.
        """
        flag_of_valid_input = True  # a flag for valid input
        while True:
            try:  # For GUI - reset the value of the button, update the message label, add insertion option,
                # update the buttons and start mainloop
                main_root.remove_insertion_option()  # remove the insertion option to add a new one
                main_root.reset_button_value()  # reset the button value
                main_root.update_message(f"{Constants.FIND_ROUND_MESSAGE}{game_id}.")
                main_root.add_insertion_option(flag_of_valid_input)
                main_root.update_button_in_gui([Constants.PREVIOUS])
                main_root.start_main_loop()
                round_number_str = main_root.get_button_value()  # get the round number from the user
                if round_number_str == Constants.PREVIOUS_PAGE_CHAR:  # if the user wants to quit
                    raise Quit
                if (round_number_str == Constants.EMPTY_STRING or
                        not round_number_str.isdigit() or int(round_number_str) < 0):
                    flag_of_valid_input = False  # if the input is invalid, inform user
                    continue
                round_number = int(round_number_str)  # user gave a valid round number
                with open(f'{Constants.RELATIVE_PATH}{game_id}', 'r') as log_file:  # open the file
                    find_round_string = f"Round {round_number} has started!"
                    log_lines = log_file.readlines()
                    for line in log_lines:  # iterate over the lines of the file
                        if find_round_string in line:
                            return find_round_string  # return the string of the round number
                    flag_of_valid_input = False  # if the round number is not found, set the flag to False
                    main_root.add_extra_message_label(f"Round {round_number} not found in game ID {game_id}.",
                                                      Constants.ERROR_COLOR)
            except FileNotFoundError:
                flag_of_valid_input = False  # if the file is not found, set the flag to False
                main_root.add_extra_message_label(f"{Constants.FILE_NOT_FOUND_ERROR}.", Constants.ERROR_COLOR)
                continue
            except Quit:  # user wants to go to the previous page
                main_root.remove_insertion_option()
                main_root.remove_extra_message_label()
                raise Quit
            except Exception as e:
                main_root.show_error(str(e))
                main_root.remove_insertion_option()

    @staticmethod
    def load_tournament_data(tournament_id: str, option_of_data: int) -> str:
        """
        A method for loading a tournament data.
        """
        try:
            if Constants.TOURNAMENT not in tournament_id:  # if the tournament_id is not a tournament
                raise FileNotFoundError
            with open(f'{Constants.RELATIVE_PATH}{tournament_id}', 'r') as log_file:  # open the file
                log_lines = log_file.readlines()
                if option_of_data == Constants.OPTION_FOR_TOURNAMENT_DATA_WINNER:  # if the user wants the winner
                    for line in log_lines:
                        if Constants.FIND_TOURNAMENT_WINNER in line:
                            new_line = line.split()  # split the line to words
                            winner_name = new_line[Constants.TOURNAMENT_WINNER_INDEX]
                            return f"{Constants.WINNER_OF}the tournament is: {winner_name}."  # return the winner
                    return Constants.NO_WINNER_OF_TOURNAMENT + tournament_id
                if option_of_data == Constants.OPTION_FOR_TOURNAMENT_DATA_ALL_DATA:  # if the user wants all the data
                    return '\n'.join(log_lines)  # return all the lines
                if option_of_data == Constants.OPTION_FOR_TOURNAMENT_DATA_WINNER_A:  # if the user wants winner of A
                    for line in log_lines:
                        if Constants.FIND_SEMI_A_WINNER in line:
                            new_line = line.split()
                            winner_name = new_line[Constants.TOURNAMENT_WINNER_INDEX]
                            return f"{Constants.WINNER_OF}semi-final A is: {winner_name}."
                    return Constants.NO_SEMI_WINNER
                if option_of_data == Constants.OPTION_FOR_TOURNAMENT_DATA_WINNER_B:  # if the user wants winner of B
                    for line in log_lines:
                        if Constants.FIND_SEMI_B_WINNER in line:
                            new_line = line.split()
                            winner_name = new_line[Constants.TOURNAMENT_WINNER_INDEX]
                            return f"{Constants.WINNER_OF}semi-final B is: {winner_name}."
                    return Constants.NO_SEMI_WINNER
                if option_of_data == Constants.OPTION_FOR_TOURNAMENT_DATA_SCORE:  # if the user wants the score
                    final_scores = []  # a list for the final scores
                    for line in log_lines:
                        if Constants.SCORE_LOGGER in line:
                            new_line = line.split()
                            start_index = new_line.index(Constants.SCORE_LOGGER) + 1
                            score_of_one_player = ' '.join(new_line[start_index:])
                            final_scores.append(score_of_one_player)
                    if not final_scores:  # if no scores were found
                        return f"{Constants.NO_SCORE_FOUND}{tournament_id}."
                    else:
                        return '\n'.join(final_scores)
            return Constants.INVALID_OPTION
        except FileNotFoundError:
            raise FileNotFoundError
        except Exception as e:  # if there is a general exception in loading the tournament data, raise it
            raise Exception(e)
