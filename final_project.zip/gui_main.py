#############################################################
# FILE : gui_main.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: GUIMain class for chinese checkers application.
#############################################################

import tkinter as tk
from tkinter import scrolledtext
from typing import Union, Optional, Callable
import tkinter.messagebox as tkmb
from board import *
from player import *


class GUIMain:
    """
    A class to represent the main GUI of the Chinese Checkers application. This class is responsible for creating the
    main GUI of the application, which will be used to navigate through the different pages of the application.
    Every page in the main class will update the message label
    and the buttons and start the main_loop event (will use the same root).
    When game is called will create the board and the game (especially with the draw board gui function).
    """

    def __init__(self) -> None:
        """
        Initialize the main GUI of the application. Will create the main window and the message
        label in the beginning of main.py.
        """
        self.__root = tk.Tk()  # create the main window
        self.__root.title(Constants.TITLE)
        try:
            self.__root.state(Constants.ROOT_GEOMETRY)  # set the size of the window
        except tk.TclError:
            self.__root.attributes('-zoomed', True)  # alternative way to maximize the window
        self.__message_label: Union[tk.Label, None] = self.__create_message_label()  # create the message label
        self.__extra_message_label: Union[tk.Label, None] = None  # create an extra message label
        self.__buttons: list[tk.Button] = []  # create a list to store the buttons
        self.__button_value = tk.StringVar()  # create a variable to store the value of the button
        self.__frame_of_insert: Union[tk.Frame, None] = None  # create a frame for the insertion option

        # bind the window close event to the quit function (make it behave exactly like the quit button)
        self.__root.protocol(Constants.REFACTOR_X_BUTTON, self.__quit_x_helper)

        # for game board, will be used when game starts
        self.__frame_of_game_board: Union[tk.Frame, None] = None  # create a frame for the game board
        self.__board: Union[Board, None] = None  # create a board
        self.__board_data: Union[list[list[Any]], None] = None  # create a board data list
        self.__selected_piece: Any = None  # flag to indicate if a piece is selected by clicking on it
        self.__clicked_piece_to_move: Any = None  # variable to store the clicked piece name
        self.__clicked_coordinate_to_move: Any = None  # variable to store the clicked coordinates to move
        self.__turn_label: Union[tk.Label, None] = None  # create a turn label
        self.__canvas: Union[tk.Canvas, None] = None  # create a canvas

    def __create_button_menu(self, list_of_options: list[str]) -> list[tk.Button]:
        """
        Create the buttons in the GUI with the given list of options.
        """
        curr_buttons = []  # create a list to store the buttons
        for i in range(len(list_of_options)):  # for each option in the list
            if list_of_options[i] == Constants.QUIT:  # if the option is quit
                button = tk.Button(self.__root, text=list_of_options[i],
                                   command=lambda: self.update_button_value(Constants.QUIT_CHAR),
                                   bg=Constants.COLOR_OF_QUIT_BUTTON, font=Constants.FONT_OF_BUTTON)
            elif (list_of_options[i] == Constants.PREVIOUS or
                  list_of_options[i] == Constants.PREVIOUS_FOR_SETTING_NUM_OF_PLAYERS):
                button = tk.Button(self.__root, text=list_of_options[i],
                                   command=lambda: self.update_button_value(Constants.PREVIOUS_CHAR),
                                   bg=Constants.COLOR_OF_PREVIOUS_BUTTON, font=Constants.FONT_OF_BUTTON)
            elif list_of_options[i] in Constants.COLORS_IN_GAME:  # if the option is a color
                command = self.__create_command(list_of_options[i])  # using helper method to create a command
                button = tk.Button(self.__root, text=list_of_options[i], bg=Constants.COLOR_MAP[list_of_options[i]],
                                   font=Constants.FONT_OF_BUTTON, command=command)
            elif list_of_options[i] in Constants.TEN_TO_TWELVE_LIST:  # if the option is 10-12
                command = self.__create_command(list_of_options[i])  # using helper method to create a command
                button = tk.Button(self.__root, text=list_of_options[i], command=command,
                                   bg=Constants.COLOR_OF_BUTTON, font=Constants.FONT_OF_BUTTON)
            else:  # for other options
                command = self.__create_command(list_of_options[i][0])  # using helper method to create a command
                button = tk.Button(self.__root, text=list_of_options[i], command=command,
                                   bg=Constants.COLOR_OF_BUTTON, font=Constants.FONT_OF_BUTTON)
            button.pack(fill=tk.BOTH, expand=True)
            curr_buttons.append(button)
        return curr_buttons

    def __create_command(self, value: str) -> Callable:
        """
        Create a command for the button (will be used to update the value of the button when
        10-12 or other buttons are clicked). Returns a command.
        """
        def command():
            # update the value of the button by given value
            self.update_button_value(value)
        return command

    def update_button_value(self, value: str) -> None:
        """
        Update the value of the button. Will affect later the input main is going to get from user in gui.
        """
        self.__button_value.set(value)  # set the value of the button
        self.__root.quit()  # quit the GUI, so that the main loop can continue (will be reset in the next page)

    def __create_message_label(self) -> tk.Label:
        """
        Create the message label in the GUI.
        """
        message_label =\
            tk.Label(self.__root, text=Constants.EMPTY_STRING,
                     font=Constants.FONT_OF_INIT_LABEL,
                     bg=Constants.COLOR_OF_BACKGROUND_LABEL, fg=Constants.COLOR_OF_TEXT_LABEL)
        message_label.pack(fill=tk.BOTH, expand=True)  # pack the label
        return message_label

    def update_message(self, message: str) -> None:
        """
        Update the message in the label of messages
        """
        if self.__message_label is None:
            self.__message_label = self.__create_message_label()  # create the message label
        self.__message_label.config(text=message)  # update the message in the label

    def remove_message_label(self) -> None:
        """
        Remove the message label from the GUI.
        """
        if self.__message_label is not None:
            self.__message_label.destroy()
            self.__message_label = None

    def get_button_value(self) -> Any:
        """
        Get the value of the button. Main will use this value to know what the user wants to do next.
        """
        if self.__button_value.get() != Constants.EMPTY_STRING:
            return self.__button_value.get()

    def reset_button_value(self) -> None:
        """
        Reset the value of the button.
        Will be used after the value of the button was used, and user have different options.
        """
        self.__button_value.set(Constants.EMPTY_STRING)

    def get_root(self) -> tk.Tk:
        """
        Get the root of the main GUI.
        """
        return self.__root

    def start_main_loop(self) -> None:
        """
        Start the main loop of the GUI.
        """
        self.__root.mainloop()

    def update_button_in_gui(self, list_of_options: list[str]) -> None:
        """
        Update the buttons in the GUI with the given list of options.
        """
        for button in self.__buttons:
            button.destroy()  # destroy the buttons
        self.__buttons = self.__create_button_menu(list_of_options)

    def __create_insertion_option(self, valid: bool) -> None:
        """
        Create an entry widget for inserting a game ID or user insertion. If it is first time,
        will shoe insert here, else, will show invalid ID.
        """
        # Create a frame to hold the entry and confirm button
        self.__frame_of_insert = tk.Frame(self.__root)
        self.__frame_of_insert.pack()
        self.__entry = tk.Entry(self.__frame_of_insert,
                                width=Constants.WIDTH_OF_ENTRY, font=Constants.FONT_OF_INSERT_ENTRY)  # create an entry
        if valid:
            self.__entry.insert(0, Constants.INSERT_HERE)  # add placeholder text
        else:
            self.__entry.insert(0, Constants.INVALID)  # add invalid ID text
            self.__entry.config(fg=Constants.COLOR_OF_ERROR_MESSAGE)  # change text color to red
        self.__entry.config(bg=Constants.INSERTION_COLOR)  # change background color to orange
        self.__entry.pack(side=tk.LEFT, padx=Constants.EXIT_PADX, pady=Constants.EXIT_PADX)
        # pack the entry widget to the left side of the frame
        # create a confirm button
        self.__confirm_button = tk.Button(self.__frame_of_insert, text=Constants.CONFIRM,
                                          font=Constants.FONT_OF_CONFIRM_BUTTON,
                                          command=lambda: self.update_button_value(self.__entry.get()),
                                          fg=Constants.COLOR_OF_CONFIRM_TEXT, bg=Constants.COLOR_OF_CONFIRM_BUTTON)
        self.__confirm_button.pack(side=tk.LEFT)  # Pack the confirm button to the left side of the frame

    def reset_button_on_screen(self) -> None:
        """
        Reset the button on the screen.
        """
        for button in self.__buttons:
            button.destroy()

    def add_insertion_option(self, valid: bool) -> None:
        """
        Add an entry widget for inserting a game ID or user insertion.
        """
        self.__create_insertion_option(valid)

    def remove_insertion_option(self) -> None:
        """
        Remove the entry widget for inserting a game ID or user insertion.
        """
        if self.__frame_of_insert is not None:  # If the frame of insert exists
            self.__frame_of_insert.destroy()

    def add_extra_message_label(self, message: str, color: str = "green") -> None:
        """
        Add an extra message label to the GUI.
        """
        if self.__extra_message_label is None:  # If the extra message label does not exist
            extra_message_label = tk.Label(self.__root, text=message, font=Constants.FONT_OF_INSERT_ENTRY,
                                           bg=color, fg=Constants.COLOR_OF_TEXT_LABEL)
            extra_message_label.pack(fill=tk.BOTH, expand=True)
            self.__extra_message_label = extra_message_label
        else:  # If the extra message label exists
            self.__extra_message_label.config(text=message, bg=color)

    def remove_extra_message_label(self) -> None:
        """
        Remove the extra message label from the GUI.
        """
        if self.__extra_message_label is not None:
            self.__extra_message_label.destroy()
            self.__extra_message_label = None

    def get_extra_message_label(self) -> Optional[tk.Label]:
        """
        Get the extra message label from the GUI.
        """
        return self.__extra_message_label

    @staticmethod
    def show_message(title: str, message: str) -> None:
        """
        Show a message box with the given title and message. Will be used to show the user data.
        """
        window = tk.Toplevel()
        window.title(title)
        # create a ScrolledText widget
        text_area = scrolledtext.ScrolledText(window, wrap=tk.WORD)
        # insert the message into the text area
        text_area.insert(tk.INSERT, message)
        # disable the text area so the user can't edit the text
        text_area.config(state=tk.DISABLED)
        text_area.pack()

    @staticmethod
    def show_error(message: str) -> None:
        """
        Show an error message box with the given title and message.
        """
        tkmb.showerror(Constants.ERROR, message)

    def __quit_x_helper(self) -> None:
        """
        Helper function to quit the GUI when the user clicks the X button (make it equal to click the Quit button).
        """
        self.update_button_value(Constants.QUIT_CHAR)  # Set the button value to 'q'

    def set_board(self, board: Board) -> None:
        """
        Set the board and board of data (by getting a copy of board list) in the GUI.
        """
        self.__board = board  # set the board
        self.__board_data = self.__board.get_copy_of_board_data_for_gui()  # get a list of lists representing the board

    def pack_board_in_gui_window(self) -> None:
        """
        Pack the board in the GUI window.
        """
        self.__frame_of_game_board = tk.Frame(self.__root, bg=Constants.COLOR_OF_BACKGROUND_FOR_BOARD)
        self.__frame_of_game_board.pack(fill=tk.BOTH, expand=True)  # pack the frame of the game board
        if self.__board is not None:
            self.__board_data = self.__board.get_copy_of_board_data_for_gui()  # get a 2D list representing the board
        self.__create_buttons_for_game()  # create the buttons
        self.__turn_label = self.__create_turn_label()  # create the turn label
        self.__canvas = self.init_canvas()  # create the canvas
        self.draw_board_gui()  # draw the board on the GUI

    def init_canvas(self) -> Optional[tk.Canvas]:
        """
        Initialize the canvas.
        """
        # Create the canvas once and store it as an instance variable
        r = Constants.RADIUS  # radius of the circle
        d = 2*r  # diameter of the circle
        space = Constants.SPACE  # space between circles
        padding = Constants.PADDING  # padding around the board
        if self.__board_data is not None:
            width = len(self.__board_data[0]) * (d + space) + 2*r + padding
            height = len(self.__board_data) * (d + space) + 2*r + padding + Constants.EXTRA_PADDING
            canvas = tk.Canvas(self.__frame_of_game_board, width=width, height=height)
            canvas.pack()  # pack the canvas
            return canvas
        return None

    def __create_buttons_for_game(self) -> None:
        """
        Create the buttons.
        """
        # Create the exit and undo button
        quit_button = tk.Button(self.__frame_of_game_board, text=Constants.EXIT_UNDO,
                                bg=Constants.COLOR_OF_BACKGROUND_EXIT_UNDO,
                                command=lambda: self.update_button_value(Constants.QUIT_CHAR),
                                width=Constants.EXIT_WIDTH, height=Constants.EXIT_HEIGHT,
                                font=Constants.FONT_OF_EXIT_UNDO, padx=Constants.EXIT_PADX, pady=Constants.EXIT_PADX)
        quit_button.pack(side=tk.LEFT)

    def __create_turn_label(self) -> tk.Label:
        """
        Create the turn label.
        """
        # Create the turn label
        turn_label = tk.Label(self.__frame_of_game_board,
                              text=Constants.WELCOME_MESSAGE, font=Constants.FONT_OF_TURN_LABEL,)
        turn_label.pack(side=tk.TOP, fill=tk.X, padx=Constants.EXIT_PADX, pady=Constants.EXIT_PADX)
        return turn_label

    @staticmethod
    def __draw_circle(canvas, x, y, r, color_code='grey', outline='black') -> int:
        """
        Draw a circle on the canvas.
        """
        color = Constants.COLOR_MAP.get(color_code, color_code)  # get the color name from the color map
        circle_id = (canvas.create_oval
                     (x-r, y-r, x+r, y+r, fill=color, outline=outline, width=Constants.WIDTH_OF_CIRCLE_ID))
        return circle_id

    def __update_possible_moves_color(self, board, canvas, coordinate_to_circle_id, highlight: bool):
        """
        Helper method updates the color of possible moves on the board (either highlight them or reset them to grey).
        """
        possible_moves = board.possible_moves(self.__selected_piece)
        for j in possible_moves.values():
            if len(j) > 0:
                for cell in j:
                    move_circle_id = coordinate_to_circle_id[cell]
                    if highlight:  # if the possible moves should be highlighted
                        canvas.itemconfig(move_circle_id, fill=Constants.POSSIBLE_MOVES_COLOR)
                    else:  # if the possible moves should be reset to grey
                        canvas.itemconfig(move_circle_id, fill=Constants.NONE_COLOR)

    def on_circle_click(self, event, canvas, circle_id, board, coordinate_to_circle_id) -> None:
        """
        Handle the event when a circle is clicked.
        """
        x_offset = Constants.COL_OFFSET
        y_offset = Constants.ROW_OFFSET
        circle_coords = canvas.coords(circle_id)  # get the coordinates of the circle
        circle_x = circle_coords[0] + Constants.RADIUS  # get the x-coordinate of the circle
        row = round(((event.y + Constants.RADIUS) - y_offset) / (2 * Constants.RADIUS + Constants.SPACE)) - 1
        col = round((circle_x - x_offset) / (2 * Constants.RADIUS + Constants.SPACE))
        clicked_cell = (row, col)  # get the cell that was clicked
        try:
            self.__clicked_piece_to_move = board.get_value_in_cell(clicked_cell)
        except ValueError:  # if the cell is out of board
            self.__clicked_piece_to_move = None  # set the clicked piece to move to None
        if self.__clicked_piece_to_move is not None:
            self.update_button_value(self.__clicked_piece_to_move)  # update the button value
        piece = self.find_piece_by_name(self.__clicked_piece_to_move)  # find the piece by its name
        # Reset the color of all possible moves to grey
        if self.__selected_piece is not None:
            self.__update_possible_moves_color(board, canvas, coordinate_to_circle_id, False)
            # reset the color of possible moves
        if piece is not None and piece != self.__selected_piece:
            self.__selected_piece = piece
            self.__update_possible_moves_color(board, canvas, coordinate_to_circle_id, True)
            # highlight the possible moves in orange
        elif piece is not None and piece == self.__selected_piece:  # if the piece is selected
            self.__selected_piece = None
        else:
            if self.__selected_piece is not None:  # if a piece is selected
                possible_moves = board.possible_moves(self.__selected_piece)
                for j in possible_moves.values():  # checking either hop or simple step
                    if len(j) > 0:  # if there are possible cells
                        for cell in j:
                            if cell == clicked_cell:  # if the clicked cell is a possible move
                                self.__clicked_coordinate_to_move = cell  # store the clicked coordinates to move
                                self.__clicked_piece_to_move = self.__selected_piece.get_name()
                                self.__selected_piece = None
                                self.update_button_value(cell)
                                self.draw_board_gui()  # redraw the board on the GUI
                                break
            else:
                current_color = canvas.itemcget(circle_id, "fill")  # get the current color of the circle
                if current_color == Constants.POSSIBLE_MOVES_COLOR:  # if the current color is orange
                    canvas.itemconfig(circle_id, fill=Constants.NONE_COLOR)  # change the color to grey

    def find_piece_by_name(self, name) -> Optional[Piece]:
        """
        Find a piece by its name.
        """
        if self.__board_data is not None:
            for row in self.__board_data:  # for each row in the board
                for cell in row:
                    if isinstance(cell, Piece) and cell.get_name() == name:
                        return cell
        return None  # if the piece is not found, return None

    def draw_board_gui(self) -> None:
        """
        Draw the GUI for the board.
        """
        board_data = self.__board_data
        r = Constants.RADIUS
        d = 2*r  # diameter of the circle
        space = Constants.SPACE  # space between circles
        if self.__canvas is not None:
            self.__canvas.delete(Constants.DELETE_PREV_CANVAS)  # clear the existing canvas
        coordinate_to_circle_id = {}  # dictionary to map coordinates to circle ids
        col_offset = Constants.COL_OFFSET
        row_offset = Constants.ROW_OFFSET
        if board_data is not None:
            for i, row in enumerate(board_data):  # for each row in the board
                for j, cell in enumerate(row):  # for each cell in the row
                    horizontal_position: float = j*(d + space) + r + col_offset  # calculate the x position
                    if i % 2 != 0:  # if row is odd - shift the x position
                        horizontal_position -= r/2  # shift the x position by half the radius
                        horizontal_position -= space  # shift the x position by the space
                    vertical_position = i*(d + space) + r + row_offset  # calculate the y position
                    if not isinstance(cell, OutOfBoard):  # if the cell is not an out of board cell
                        color_code = Constants.NONE_COLOR  # default color code
                        if isinstance(cell, Piece):
                            color_code = cell.get_color()  # get the color of the piece
                            if color_code not in Constants.COLOR_MAP:  # if the color is not in the color map
                                color_code = Constants.UNIDENTIFIED_COLOR_CODE  # set the color to white
                        circle_id = self.__draw_circle(self.__canvas, horizontal_position, vertical_position,
                                                       r, color_code)
                        coordinate_to_circle_id[(i, j)] = circle_id  # map the coordinate to the circle id
                        # bind the circle to the on_circle_click event
                        def on_circle_click_event(event, canvas=self.__canvas, my_circle_id=circle_id,
                                                  board=self.__board, coordinate_circle_id=None):
                            if coordinate_circle_id is None:
                                coordinate_circle_id = coordinate_to_circle_id  # get the coordinate to circle id
                            self.on_circle_click(event, canvas, my_circle_id, board, coordinate_circle_id)
                        if self.__canvas is not None:
                            self.__canvas.tag_bind(circle_id, Constants.PRESSING_MOUSE, on_circle_click_event)
                    else:  # if the cell is an out of board cell
                        self.__draw_circle(self.__canvas, horizontal_position, vertical_position,
                                           r, color_code=Constants.OUT_OF_BOARD_COLOR,
                                           outline=Constants.OUT_OF_BOARD_OUTLINE)

    def get_input_from_user(self) -> Optional[str]:
        """
        Get the input from the user. Will be used to get the input from the user in the GUI, immediately after getting
        the button value, the main loop will be quit and the input will be returned.
        """
        if self.__button_value.get():  # if the button is clicked
            return self.__button_value.get()  # return the value of the button
        return None

    def update_turn_label(self, player_turn: Player, string_to_player: str) -> None:
        """
        Update the turn label to show the player's turn.
        """
        color_code = player_turn.get_color()  # get the color code of the player
        color = Constants.COLOR_MAP.get(color_code, color_code)  # get the color name from the color map
        dark_colors = Constants.DARK_COLOR
        if color in dark_colors:
            text_color = "white"
        else:
            text_color = "black"
        if self.__turn_label is not None:
            self.__turn_label.config(text=string_to_player, bg=color, fg=text_color)  # update the turn label

    def update_turn_label_with_string(self, string: str) -> None:
        """
        Update the turn label with a string (normally represents score of players).
        """
        if self.__turn_label is not None:
            self.__turn_label.config(text=string, font=Constants.FONT_OF_LABEL_SMALL)

    def refresh_gui(self):
        """
        Refresh the GUI to reflect the updated board data.
        """
        self.__canvas.delete("all")  # delete all existing items from the canvas
        self.draw_board_gui()  # redraw the board on the GUI

    def reset_widgets(self):
        """
        Reset the widgets in the GUI.
        """
        self.reset_button_value()  # reset the value of the button
        self.reset_button_on_screen()  # reset the buttons on the screen
        self.remove_insertion_option()  # remove the insertion option
        self.remove_extra_message_label()  # remove the extra message label
        self.remove_message_label()
        if self.__frame_of_game_board is not None:
            self.__frame_of_game_board.destroy()  # destroy the frame of the game board
        self.__frame_of_game_board = None  # reset the frame of the game board

    @staticmethod
    def helper_for_setting_gui_for_next_page(main_root: "GUIMain",
                                             main_message: str, list_of_options_for_buttons: list[str]) -> None:
        """
        Helper method for setting the GUI for the next page. Common actions for most of the pages. Exclude insertion.
        """
        main_root.reset_button_value()  # reset the value of the button
        main_root.update_message(main_message)  # update the message label
        main_root.update_button_in_gui(list_of_options_for_buttons)  # update the buttons
        main_root.start_main_loop()  # start the main loop
