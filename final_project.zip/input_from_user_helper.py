#############################################################
# FILE : input_from_user_helper.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: InputFromUser class for chinese checkers game
#############################################################
from gui_main import GUIMain, Any
from constants import *


class InputFromUser:
    """
    helper class for getting input from user when setting a player. Will be used in the main menu and tournament.
    """
    @staticmethod
    def getting_input_for_a_single_player(main_root: GUIMain, num_of_players: int,
                                          list_of_available_colors: list[str],
                                          list_of_names: list[str]) -> Any:
        """
        halper method for managing the input from user from one single player.
        :return: a list of the player's data [type of player, player name, player color, player strategy]
        """
        while True:
            list_of_single_player_data: list[Any] = []  # collect the data of the player
            player_type = InputFromUser.__new_player_type(main_root)  # get the player type
            if player_type == QuitGame:
                return QuitGame
            if player_type == PreviousPage:
                return PreviousPage  # go back to previous page (question of number of players)
            while True:
                if main_root.get_extra_message_label() is not None:  # if there is an extra message label
                    main_root.remove_extra_message_label()  # remove the extra message label
                player_name = InputFromUser.__new_player_name(main_root, player_type, list_of_names)
                if player_name == QuitGame:
                    return QuitGame
                if player_name == PreviousPage:
                    break  # go back to previous page (question of player type)
                while True:
                    player_color = InputFromUser.__new_player_color(main_root, list_of_available_colors)
                    if player_color == QuitGame:
                        return QuitGame
                    if player_color == PreviousPage:
                        break  # go back to previous page (question of player name)
                    while True:
                        if player_type == Constants.TYPE_COMPUTER:
                            player_strategy = InputFromUser.__computer_level(main_root, num_of_players)
                            if player_strategy == QuitGame:
                                return QuitGame
                            if player_strategy == PreviousPage:
                                break  # go back to previous page (question of player color)
                        else:
                            player_strategy = None
                        list_of_single_player_data.append(player_type)  # index 0 - type of player
                        list_of_single_player_data.append(player_name)  # index 1 - player name
                        list_of_single_player_data.append(player_color)  # index 2 - player color
                        list_of_single_player_data.append(player_strategy)  # index 3 - player strategy
                        list_of_names.append(player_name)  # add the player name to the list of names
                        list_of_available_colors.remove(player_color)  # remove the color from the available colors
                        return list_of_single_player_data

    @staticmethod
    def new_num_of_players(main_root: GUIMain) -> Any:
        """
        Set the number of players for the new game.
        """
        while True:
            # For GUI - reset the value of the button, update the message label,
            # update the buttons and start mainloop
            main_root.remove_extra_message_label()  # remove the extra message label
            list_of_options = Constants.OPTIONS_FOR_PLAYERS + [Constants.PREVIOUS, Constants.QUIT]
            GUIMain.helper_for_setting_gui_for_next_page(main_root,
                                                         Constants.EXPLANATION_FOR_NEW_GAME, list_of_options)
            num_of_players = main_root.get_button_value()  # get the value of the button (clicked - loop will stop)
            if num_of_players == Constants.PREVIOUS_BOTTOM:
                return PreviousPage  # go back to previous page (game menu)
            elif num_of_players == Constants.QUIT_BOTTOM:
                return QuitGame
            if num_of_players not in Constants.OPTIONS_FOR_PLAYERS:
                main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again
            else:
                return int(num_of_players)

    @staticmethod
    def __new_player_type(main_root: GUIMain) -> Any:
        """
        Set the player type for the new game.
        """
        while True:
            # For GUI - reset the value of the button, update the message label,
            # update the buttons and start mainloop
            list_of_options = Constants.OPTIONS_FOR_TYPE_WORDS + [Constants.PREVIOUS_FOR_SETTING_NUM_OF_PLAYERS,
                                                                  Constants.QUIT]
            GUIMain.helper_for_setting_gui_for_next_page(main_root, Constants.SET_PLAYER_TYPE, list_of_options)
            player_type = main_root.get_button_value()  # get the value of the button (clicked - loop will stop)
            if player_type == Constants.PREVIOUS_BOTTOM:
                return PreviousPage  # go back to previous page (question of number of players)
            elif player_type == Constants.QUIT_BOTTOM:
                return QuitGame  # quit the game
            if player_type not in Constants.OPTIONS_FOR_TYPE:
                main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again
            else:
                return int(player_type)

    @staticmethod
    def __new_player_name(main_root: GUIMain, player_type: int, list_of_names: list[str]) -> Any:
        """
        Set the player name for the new game.
        """
        valid_name_flag = True  # flag for valid name
        while True:
            # For GUI - reset the value of the button, update the message label, add insertion option,
            # update the buttons and start mainloop
            try:
                main_root.add_insertion_option(valid_name_flag)
                (GUIMain.helper_for_setting_gui_for_next_page
                 (main_root, Constants.SET_PLAYER_NAME, [Constants.PREVIOUS, Constants.QUIT]))
                player_name = main_root.get_button_value()  # get the value of the button (clicked - loop will stop)
                if player_name == Constants.PREVIOUS_BOTTOM:
                    main_root.remove_insertion_option()  # first, remove the insertion option
                    return PreviousPage  # go back to previous page (question of player type)
                elif player_name == Constants.QUIT_BOTTOM:
                    return QuitGame
                if len(player_name) == 0 or player_name in list_of_names:  # if the name is empty or already exists
                    valid_name_flag = False
                    main_root.remove_insertion_option()  # invalid name, change the flag and try again
                    continue  # invalid input, try again (will be colored in red)
                if player_type == Constants.TYPE_COMPUTER:
                    if not player_name.startswith(Constants.COMPUTER_NAME) or (Constants.NOT_ONE_WORD in player_name):
                        valid_name_flag = False
                        main_root.remove_insertion_option()  # invalid name, change the flag and try again
                        continue  # invalid input, try again (will be colored in red)
                    else:
                        main_root.remove_insertion_option()  # remove the insertion option and return the valid name
                        return player_name  # return the valid name
                if player_type == Constants.TYPE_HUMAN:
                    if (Constants.NOT_ONE_WORD in player_name or player_name[0].isupper() is False
                            or player_name.startswith(Constants.COMPUTER_NAME)):
                        # if more than one word, or not start with capital letter, or start with Computer
                        valid_name_flag = False
                        main_root.remove_insertion_option()  # invalid name, change the flag and try again
                        continue  # invalid input, try again (will be colored in red)
                    else:
                        main_root.remove_insertion_option()  # remove the insertion option and return the valid name
                        return player_name
            except Exception as e:  # probably inserted an empty name
                valid_name_flag = False
                main_root.show_error(str(e))
                main_root.remove_insertion_option()

    @staticmethod
    def __new_player_color(main_root: GUIMain, list_of_available_color: list[str]) -> Any:
        """
        Set the player color for the new game.
        """
        while True:
            # For GUI - reset the value of the button, update the message label,
            # update the buttons and start mainloop
            list_of_options = list_of_available_color + [Constants.PREVIOUS, Constants.QUIT]
            GUIMain.helper_for_setting_gui_for_next_page(main_root, Constants.SET_PLAYER_COLOR, list_of_options)
            player_color = main_root.get_button_value()  # get the value of the button (clicked - loop will stop)
            if player_color == Constants.PREVIOUS_BOTTOM:
                return PreviousPage  # go back to previous page (question of player name)
            elif player_color == Constants.QUIT_BOTTOM:
                return QuitGame
            if player_color not in list_of_available_color:  # if the color is not available
                main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again
            else:
                return player_color

    @staticmethod
    def __computer_level(main_root: GUIMain, num_of_players: int) -> Any:
        """
        Set the computer level for the new game.
        """
        while True:
            # For GUI - reset the value of the button, update the message label,
            # update the buttons and start mainloop
            if num_of_players == int(Constants.SIX):
                explanation = f"{Constants.EXPLANATION_FOR_COMPUTER_LEVEL}\n{Constants.LEVEL_3_ADDITION}"
                list_of_options = Constants.OPTIONS_FOR_LEVEL + [Constants.PREVIOUS, Constants.QUIT]
            else:
                explanation = Constants.EXPLANATION_FOR_COMPUTER_LEVEL
                list_of_options = Constants.OPTIONS_FOR_LEVEL[:2] + [Constants.PREVIOUS, Constants.QUIT]
            GUIMain.helper_for_setting_gui_for_next_page(main_root, explanation, list_of_options)
            computer_level = main_root.get_button_value()  # get the value of the button (clicked - loop will stop)
            if computer_level == Constants.PREVIOUS_BOTTOM:
                return PreviousPage  # go back to previous page (question of player color)
            elif computer_level == Constants.QUIT_BOTTOM:
                return QuitGame
            if computer_level not in Constants.OPTIONS_FOR_LEVEL:
                main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again
            elif num_of_players < int(Constants.SIX) and computer_level == Constants.THREE:
                main_root.show_error(Constants.INVALID_INPUT)
                # invalid input, try again (level 3 is not available for 2-4 players)
            else:
                return int(computer_level)
