#############################################################
# FILE : strategy.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: strategy class for chinese checkers game
#############################################################
import random
from board import *
from piece import Piece
from player import Player
from constants import *
from typing import Any


class Strategy:

    """
    This class represents the strategy for the computer in the game. The class contains 3 level of difficulties
    for the computer to play: LEVEL 1 - random move, LEVEL 2 - best move,
    LEVEL 3 - best move + disturbing the opponents. Game class calls one of the methods with current board
    and a computer player, and get a tuple with a piece and new coordinates for the piece to move.
    All 3 methods are static methods, so they can be called without creating an instance of the class.
    As well, methods uses a lot of inner methods to help them.
    """

    @staticmethod
    def get_random_coordinate(current_board: Board, computer_player: Player) -> tuple[Piece, tuple[int, int]]:
        """
        This method returns a tuple of piece and new coordinates, which are chosen randomly. LEVEL 1.
        """
        while True:  # loop until a valid move is found
            pieces = computer_player.get_pieces_of_player()
            piece_to_move: Piece = random.choice(pieces)  # choose a random piece from player's pieces
            dict_of_possible_moves = current_board.possible_moves(piece_to_move)  # get all possible moves for the piece
            random_list_of_kind_of_move: list[tuple[int, int]] = random.choice(list(dict_of_possible_moves.values()))
            # choose a random move from the dict values: hop or simple step
            if len(random_list_of_kind_of_move) > 0:  # if there are possible cells
                random_cell: tuple[int, int] = random.choice(random_list_of_kind_of_move)
                break
        # choose a random move from the dict values
        return piece_to_move, random_cell

    @staticmethod
    def get_best_coordinate(current_board: Board, computer_player: Player) -> tuple[Piece, tuple[int, int]]:
        """
        This method returns a tuple of piece and new coordinates, which are chosen by the best strategy. LEVEL 2.
        """
        while True:  # loop until a valid move is found
            check_for_infinity: tuple[Piece, tuple[int, int]] =\
                Strategy.__preventing_infinity_game_for_two_computers(current_board, computer_player)
            if check_for_infinity is not None:  # if the method returned a move (means we can prevent infinity game)
                return check_for_infinity   # else, either piece is stuck or no piece in the inner cell
            dict_of_grades_for_all_moves = {}  # dictionary of grades for all possible moves
            pieces = computer_player.get_pieces_of_player()  # get all pieces of the player
            direction = Strategy.__check_direction(computer_player)  # check the direction of attack for the computer
            for piece_to_move in pieces:  # iterate over all pieces of the player
                current_cell = piece_to_move.get_coordinate()
                dict_of_possible_moves = current_board.possible_moves(piece_to_move)
                for j in dict_of_possible_moves.values():  # checking either hop or simple step
                    if len(j) > 0:  # if there are possible cells
                        for cell in j:
                            potential_next_cell = cell  # potential next cell to check
                            grade = (Strategy.__rate_move_for_all_directions
                                     (computer_player, current_cell, potential_next_cell, direction))  # rate the move
                            dict_of_grades_for_all_moves[(piece_to_move, potential_next_cell)] = grade  # add to dict
            # after rating all possible moves, choose the best move
            best_grade = max(dict_of_grades_for_all_moves.values())  # get the best grade
            best_moves = [move for move, grade in dict_of_grades_for_all_moves.items()
                          if grade == best_grade]  # get all the best moves into a list
            best_move = random.choice(best_moves)  # choose a random best move
            return best_move

    @staticmethod
    def get_best_coordinate_master(current_board: Board, computer_player: Player) -> tuple[Piece, tuple[int, int]]:
        """
        This method returns a tuple of piece and new coordinates, which are chosen by the unique strategy. Method
        keeps 5 pieces that aims to go to opponent target list in order to disturb them. When all the rest of the pieces
        gets to the target triangle, they are going to join them.
        Recommended to use in 6 participants. LEVEL 3.
        """
        dict_of_pieces_and_target_disturb: dict[Piece, list[tuple[int, int]]]\
            = Strategy.__disturb_helper_create_dict_of_pieces_and_target_disturb(current_board, computer_player)
        # create a dictionary of pieces and their target to disturb by a helper method.
        if Strategy.__check_if_rest_of_pieces_got_to_target(computer_player,
                                                            dict_of_pieces_and_target_disturb) is False:
            # if the rest of the pieces (which are not disturbing) did not get to the target triangle, try the strategy
            if random.randint(1, Constants.RATE_OF_DISTURB) == 1:  # if the random number is 1, disturb the opponent
                while True:  # loop until a move is found
                    try:
                        try:
                            disturb_piece = random.choice(list(dict_of_pieces_and_target_disturb.keys()))
                            # choose a random piece to disturb
                            Strategy.get_best_coordinate(current_board, computer_player)
                            if (Strategy.__check_if_piece_is_in_disturbing_target
                                    (disturb_piece, dict_of_pieces_and_target_disturb) is False):
                                disturbing_move = (Strategy.__aim_piece_to_disturb
                                                   (disturb_piece, dict_of_pieces_and_target_disturb[disturb_piece],
                                                    current_board))  # aim the piece to disturb
                                return disturbing_move  # return the best move for the piece to disturb
                            elif (Strategy.__check_if_all_pieces_in_disturbing_target
                                    (dict_of_pieces_and_target_disturb) is True):
                                break  # if all the pieces are in the disturbing target, break the loop and continue
                            else:
                                raise ValueError  # if the piece is already in the disturbing target, raise exception
                        except IndexError:  # if the list of pieces to disturb is empty
                            return Strategy.get_best_coordinate(current_board, computer_player)
                    except ValueError:
                        continue
            while True:  # loop until a move is found
                try:
                    counter_of_trying = 0
                    while counter_of_trying < Constants.NUM_OF_TRIES_FOR_BEST_MOVE:
                        # counter for the while loop (num of tryings to find a move without disturb pieces)
                        best_move = Strategy.get_best_coordinate(current_board, computer_player)
                        if best_move[0] not in dict_of_pieces_and_target_disturb.keys():
                            return best_move  # if the piece is not disturbed, return the best move for the piece
                        else:
                            counter_of_trying += 1
                    raise ValueError  # if the best move available is disturbing piece, raise exception
                except ValueError:
                    return Strategy.get_best_coordinate(current_board, computer_player)  # return best move instead
        else:  # if the rest of the pieces (which are not disturbing) got to the target triangle, use the best strategy
            return Strategy.get_best_coordinate(current_board, computer_player)

    @staticmethod
    def __rate_move_for_all_directions(computer_player: Player, current_cell: tuple[int, int],
                                       potential_next_cell: tuple[int, int], direction: str) -> int:
        """
        This method rates the best move for the computer in both vertical and diagonal games.
        """
        aim_height = 0.0
        if direction in [Constants.UP, Constants.DOWN]:  # vertical directions
            direction_multiplier = -1 if direction == Constants.UP else 1  # multiplier for the direction
            difference = direction_multiplier * (potential_next_cell[0] - current_cell[0])  # row difference
        else:  # diagonal directions
            if direction == Constants.UP_RIGHT:
                direction_multiplier = 1
                aim_height = Constants.AIM_HEIGHT_FOR_TARGET_2
            elif direction == Constants.UP_LEFT:
                direction_multiplier = -1
                aim_height = Constants.AIM_HEIGHT_FOR_TARGET_6
            elif direction == Constants.DOWN_RIGHT:
                direction_multiplier = 1
                aim_height = Constants.AIM_HEIGHT_FOR_TARGET_3
            else:  # if "DOWN_LEFT"
                direction_multiplier = -1
                aim_height = Constants.AIM_HEIGHT_FOR_TARGET_5
            difference = direction_multiplier * (potential_next_cell[1] - current_cell[1])  # column difference

        if difference >= Constants.BIG_JUMP or (
                Strategy.__is_in_target(computer_player, potential_next_cell) is True
                and Strategy.__is_in_target(computer_player, current_cell) is False):
            return Constants.GRADE_A  # if the jump is big or the piece will get to the target triangle

        if difference >= Constants.MEDIUM_JUMP or (
                Strategy.__is_in_target(computer_player, potential_next_cell) is True
                and Strategy.__is_in_target(computer_player, current_cell) is True
                and difference >= Constants.SIMPLE_STEP_FORWARD):
            return Constants.GRADE_B
            # if the jump is medium or the piece will get better location inside the target triangle

        if direction in [Constants.UP_RIGHT, Constants.UP_LEFT, Constants.DOWN_RIGHT,
                         Constants.DOWN_LEFT]:  # diagonal directions
            if (abs(aim_height - potential_next_cell[0]) <= Constants.CLOSE_TO_TARGET_RATE
                    and (abs(aim_height - current_cell[0]) > Constants.CLOSE_TO_TARGET_RATE)):
                return Constants.GRADE_B  # for diagonal moves, if the piece will get close to the target triangle

        if difference >= Constants.SMALL_JUMP:
            return Constants.GRADE_C  # if the jump is small

        if direction in [Constants.UP_RIGHT, Constants.UP_LEFT, Constants.DOWN_RIGHT,
                         Constants.DOWN_LEFT]:  # diagonal directions
            if (abs(aim_height - potential_next_cell[0]) <=
                    (abs(aim_height - current_cell[0]))):
                return Constants.GRADE_C  # for diagonal moves, if the piece will get closer to the target triangle

        if difference >= Constants.SIMPLE_STEP_FORWARD:
            return Constants.GRADE_D  # if the jump is a simple step forward

        return Constants.GRADE_E

    @staticmethod
    def __is_in_target(computer_player: Player, cell_to_check: tuple[int, int]) -> bool:
        """
        This method checks if cell is in the target triangle.
        """
        if cell_to_check in Constants.DICT_OF_TRIANGLES[computer_player.get_target_triangle()]:
            return True
        else:
            return False

    @staticmethod
    def __check_direction(computer_player: Player) -> str:
        """
        This method checks the direction of attack for the computer.
        """
        if computer_player.get_target_triangle() == "A" or computer_player.get_target_triangle() == "1":
            return Constants.UP  # if the target triangle is A or 1, the direction is up
        if computer_player.get_target_triangle() == "B" or computer_player.get_target_triangle() == "4":
            return Constants.DOWN  # if the target triangle is B or 4, the direction is down
        if computer_player.get_target_triangle() == "2":
            return Constants.UP_RIGHT  # if the target triangle is 2, the direction is up right
        if computer_player.get_target_triangle() == "3":
            return Constants.DOWN_RIGHT  # if the target triangle is 3, the direction is down right
        if computer_player.get_target_triangle() == "5":
            return Constants.DOWN_LEFT  # if the target triangle is 5, the direction is down left
        return Constants.UP_LEFT  # else, the direction is up left

    @staticmethod
    def __aim_piece_to_disturb(disturbing_piece: Piece, cell_to_disturb_list: list[tuple[int, int]],
                               current_board: Board) -> tuple[Piece, tuple[int, int]]:
        """
        This method aims to disturb the opponent by choosing 5 pieces that will aim to go to the opponent target
        triangle. The method gets a piece and aimed cells to disturb, returns the best move for it towards the cell.
        """
        while True:
            dict_of_possible_moves = current_board.possible_moves(disturbing_piece)  # get all possible moves for piece
            dict_of_distances = {}  # dictionary of min distance for each possible move (cell)
            for j in dict_of_possible_moves.values():  # checking either hop or simple step
                if len(j) > 0:  # if there are possible cells
                    for cell in j:  # iterate over all possible cells
                        list_of_distances_for_each_possible_move = []  # list of distances for each possible move
                        for i in cell_to_disturb_list:  # iterate over all cells to disturb list
                            if cell == i:  # if we can move directly to one of the cell
                                return disturbing_piece, cell
                            distance_from_cell = abs(cell[0] - i[0]) + abs(cell[1] - i[1])  # calculate the distance
                            list_of_distances_for_each_possible_move.append(distance_from_cell)
                            if len(list_of_distances_for_each_possible_move) > 0:
                                min_distance_for_each_cell = min(list_of_distances_for_each_possible_move)
                                # get the min distance for cell
                                dict_of_distances[cell] = min_distance_for_each_cell
            min_distance_rate = min(dict_of_distances.values())  # get the min distance rate of all cell
            best_cells_to_move = [cell for cell, distance in dict_of_distances.items() if distance == min_distance_rate]
            # get all the cells with the minimum distance rate move into a list
            best_cell_to_move = random.choice(best_cells_to_move)  # choose one of them randomly
            return disturbing_piece, best_cell_to_move

    @staticmethod
    def __disturb_helper_create_dict_of_pieces_and_target_disturb(current_board: Board,
                                                                  computer_player: Player) ->\
            dict[Piece, list[tuple[int, int]]]:
        """
        This method creates a dictionary of pieces and their target to disturb.
        """
        dict_of_pieces_and_target_disturb: dict[Piece, list[tuple[int, int]]] = {}
        # dictionary of pieces and their target to disturb
        counter = 0  # counter for the while loop
        i = 0  # index for accessing pieces and cells to disturb
        pieces = computer_player.get_pieces_of_player()  # get all pieces of the player
        while counter < 5 and i < len(Constants.LIST_OF_CELLS_TO_DISTURB):
            # iterate until 5 pieces are found or all pieces are checked
            piece_to_disturb = pieces[i]  # get the piece to disturb
            if (not all(cell in Constants.DICT_OF_TRIANGLES
                [computer_player.get_target_triangle()] for cell in Constants.LIST_OF_CELLS_TO_DISTURB[i])
                    and Strategy.__check_if_can_move(current_board, piece_to_disturb) is True):
                # if the list is not in the target triangle and the piece can move
                cells_to_disturb = Constants.LIST_OF_CELLS_TO_DISTURB[i]
                dict_of_pieces_and_target_disturb[piece_to_disturb] = cells_to_disturb
                # add the piece and the cells to disturb list to the dictionary
                counter += 1
            i += 1  # increment the index to check the next piece and cell to disturb
        return dict_of_pieces_and_target_disturb

    @staticmethod
    def __check_if_can_move(curr_board: Board, piece_to_move: Piece) -> bool:
        """
        This method checks if the piece can move somewhere.
        """
        for j in curr_board.possible_moves(piece_to_move).values():  # checking either hop or simple step
            if len(j) > 0:  # if there are possible cells to move
                return True
        return False

    @staticmethod
    def __check_if_rest_of_pieces_got_to_target(computer_player: Player,
                                                dict_of_disturbing_pieces: dict[Piece, list[tuple[int, int]]]) -> bool:
        """
        This method checks if the rest of the pieces (which are not disturbing) got to the target triangle.
        """
        for piece_to_check in computer_player.get_pieces_of_player():  # iterate over all pieces of the player
            if piece_to_check not in dict_of_disturbing_pieces.keys():  # if the piece is not disturbing
                if (piece_to_check.get_coordinate()
                        not in Constants.DICT_OF_TRIANGLES[computer_player.get_target_triangle()]):
                    return False  # return false if even one of the pieces is not in the target triangle
        return True

    @staticmethod
    def __check_if_piece_is_in_disturbing_target(piece_to_check: Piece,
                                                 dict_of_disturbing_pieces: dict[Piece, list[tuple[int, int]]]) -> bool:
        """
        This method checks if the piece is in the disturbing target.
        """
        for i in dict_of_disturbing_pieces:  # iterate over all pieces in the disturbing target
            if piece_to_check == i:  # if the piece is in the disturbing target
                if piece_to_check.get_coordinate() in dict_of_disturbing_pieces[i]:
                    return True  # if the piece's cell is in disturb target
        return False

    @staticmethod
    def __check_if_all_pieces_in_disturbing_target(dict_of_disturbing_pieces: dict[Piece, list[tuple[int, int]]])\
            -> bool:
        """
        This method checks if all the pieces are in the disturbing target.
        """
        for piece_to_check in dict_of_disturbing_pieces.keys():  # iterate over all pieces in the disturbing target
            if Strategy.__check_if_piece_is_in_disturbing_target(piece_to_check, dict_of_disturbing_pieces) is False:
                return False  # return false if even one of the pieces is not in the disturbing target
        return True

    @staticmethod
    def __preventing_infinity_game_for_two_computers(current_board: Board, computer_player: Player) -> Any:
        """
        This method prevents an infinite game for two computers.
        """
        home_of_computer = computer_player.get_home_triangle()  # get the home triangle of the computer
        inner_cell = Constants.INNER_CELL_A  # the inner cell of the home triangle will be default (0, 6)
        if home_of_computer == "B":  # else
            inner_cell = Constants.INNER_CELL_B  # the inner cell of the home triangle will be (16, 6)
        for piece_to_check in computer_player.get_pieces_of_player():  # iterate over all pieces of the player
            if piece_to_check.get_coordinate() == inner_cell:  # if the piece is in the inner cell
                for j in current_board.possible_moves(piece_to_check).values():
                    if len(j) > 0:  # if there are possible cells to move
                        cell_to_move: tuple[int, int] = random.choice(j)  # choose a random cell to move
                        return piece_to_check, cell_to_move  # return the piece and the cell to move
