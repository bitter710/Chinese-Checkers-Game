#############################################################
# FILE : piece.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: piece class for chinese checkers game
#############################################################
from colorama import Fore, Style
from constants import *


class Piece:

    """A class representing a piece in the game. initialized with a color, a number and a coordinate.
    Some of the methods can be used in other classes, such like get_name, get_coordinate, move and more.
    """

    def __init__(self, color: str, number: int, coordinate: tuple[int, int]) -> None:
        """A constructor for the piece class. initialized with a color, a number and a coordinate.
        """
        if isinstance(color, str) and color.isupper() is True and len(color) == Constants.LEGAL_COLOR_LENGTH:
            self.__color = color  # check if color is legal
        else:
            raise ValueError(Constants.ILLEGAL_COLOR)

        if isinstance(number, int) and number >= Constants.MIN_NUMBER:  # check if number is legal
            if number < Constants.DOUBLE_DIGIT_NUMBER:
                self.__number = Constants.ZERO_STRING + str(number)  # if the number is less than 10, add 0 before num
            else:
                self.__number = str(number)
        else:
            raise ValueError(Constants.ILLEGAL_NUMBER)

        self.__name = str(self.__color + str(self.__number))  # create a name for the piece

        if self.__check_illegal_coordinate_for_piece(coordinate) is True:
            #  when initializing, calling a helper method that checks if coordinate is legal.
            #  otherwise, Exception will be raised in the helper method.
            self.__coordinate = coordinate  # assign the coordinate to the piece

    def get_name(self) -> str:
        """A method that returns the name of the piece.
        """
        return self.__name

    def get_color(self) -> str:
        """A method that returns the color of the piece.
        """
        return self.__color

    def get_number(self) -> int:
        """A method that returns the number of the piece.
        """
        return int(self.__number)  # return the number as an integer

    def get_coordinate(self) -> tuple[int, int]:
        """A method that returns the coordinate of the piece.
        """
        return self.__coordinate

    def __str__(self) -> str:
        """A method that returns the name of the piece with color.
        """
        if self.__color == 'R':
            return Fore.RED + self.__name + Style.RESET_ALL
        if self.__color == 'G':
            return Fore.GREEN + self.__name + Style.RESET_ALL
        if self.__color == 'B':
            return Fore.BLUE + self.__name + Style.RESET_ALL
        if self.__color == 'Y':
            return Fore.YELLOW + self.__name + Style.RESET_ALL
        if self.__color == 'P':
            return Fore.MAGENTA + self.__name + Style.RESET_ALL
        return self.__name  # if the color is not one of the above, the method will return the name without color

    def move(self, new_coordinate: tuple[int, int]) -> bool:
        """A method that moves the piece to a new coordinate. Pay attention that piece can move everywhere
        the coordinate is valid (any limits related to occupied cells has nothing to do with pieces consideration).
        After the move, the method returns True.
        """
        try:
            if self.__check_illegal_coordinate_for_piece(new_coordinate) is True:
                # calling a helper method to check if legal
                self.__coordinate = new_coordinate  # change the coordinate of the piece
                return True
        except ValueError:  # if the coordinate is illegal, the method will return False
            return False
        return False
        # General note: if the move is illegal, the method will return False and handle the exception by itself.

    @staticmethod
    def __check_illegal_coordinate_for_piece(coordinate: tuple[int, int]) -> bool:
        """A method that checks if the coordinate is legal. If it is, the method returns True.
        """
        if isinstance(coordinate, tuple) and len(coordinate) == Constants.LENGTH_OF_COORDINATE:  # check if legal
            for i in coordinate:  # check if value of coordinates is legal (not negative and integer)
                if not isinstance(i, int) or i < 0:
                    raise ValueError(Constants.ILLEGAL_COORDINATE)
            return True
        else:
            raise ValueError(Constants.ILLEGAL_COORDINATE)
