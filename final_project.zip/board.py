#############################################################
# FILE : board.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: board class for chinese checkers game
#############################################################
from typing import Any
from dataclasses import dataclass
from piece import Piece
from constants import *
import copy


@dataclass
class OutOfBoard:
    """A named tuple to represent a cell that is out of the board."""
    row: int
    col: int

    def __str__(self) -> str:
        return '000'  # print the cell in black color


class Board:

    """Class for the board of chinese checkers game. It contains a board list,
    two dictionaries to keep track of board changes. It has methods to display the board,
    get possible moves in board, add and move pieces and more"""

    def __init__(self) -> None:
        """Constructor for the board class. It creates the main board list
         and dictionaries of cells and pieces on the board."""
        self.__current_board: list[Any] = self.__create_board()
        # first we create an empty board, using a private method
        self.__dict_of_pieces_on_board: dict[str, tuple[int, int]] = {}
        # create an empty dictionary of pieces on the board (pieces are not yet placed on the board, will be the keys)
        self.__dict_of_cells_on_board = self.__create_dict_of_cells_on_board()
        # create a dictionary of cells on the board ( this is my way to keep track of the cells on the board)

    def __create_board(self) -> list[Any]:
        """ A private method to create the board. It creates the board as a list of lists, where each list is a row"""
        my_board: list[Any] = []
        # Create the top triangle of the board
        my_board = self.__create_board_helper(my_board, 1, Constants.TOP_TRIANGLE_SIZE, 1)
        # Create the top half of the body of the board
        my_board = self.__create_board_helper(my_board,
                                              Constants.TOP_HALF_BODY_SIZE_START, Constants.TOP_HALF_BODY_SIZE_END, -1)
        # Create the bottom half of the body of the board
        my_board = self.__create_board_helper(my_board, Constants.BOTTOM_HALF_BODY_SIZE_START,
                                              Constants.BOTTOM_HALF_BODY_SIZE_END, 1)
        # Create the bottom triangle of the board
        my_board = self.__create_board_helper(my_board, Constants.BOTTOM_TRIANGLE_SIZE - 1, 0, -1)
        return my_board

    @staticmethod
    def __create_board_helper(current_board: list[Any], int_to_start: int, int_to_end: int, steps: int) -> list[Any]:
        """A private helper method to create a part of the board.
         It iterates rows of the board and assign them into a list."""
        for j in range(int_to_start, int_to_end, steps):  # iterate over the rows of the board
            out_of_board_calls_in_row = [OutOfBoard(i, j) for i in range((Constants.ENTIRE_BOARD_WIDTH - j) // 2)]
            #  create a list of out of board cells for the current row,
            #  considering OutOfBoard cells, None cells represent empty cells
            row = out_of_board_calls_in_row + ([None] * j) + out_of_board_calls_in_row
            current_board.append(row)
        return current_board

    def __create_dict_of_cells_on_board(self) -> dict[tuple[int, int], Any]:
        """A private method to create a dictionary of cells on the board.
         It creates a dictionary where the keys are the coordinates of the cells and the values are the cells."""
        dict_of_cells = {}
        for row_index, row in enumerate(self.__current_board):  # iterate over the rows of the board
            for cell_index, cell in enumerate(row):  # iterate over the cells of the row
                if isinstance(cell, OutOfBoard):  # if the cell is out of the board, continue to the next cell
                    continue
                dict_of_cells[(row_index, cell_index)] = cell  # add the cell to the right coordinate in the dictionary
        return dict_of_cells

    def add_piece_to_board(self, new_piece: Piece) -> bool:
        """A method to add a valid piece to the board. API assumes it gets valid piece.
         It adds the piece to the board and to the dictionary of pieces on the board."""
        if new_piece.get_coordinate() not in self.__dict_of_cells_on_board.keys():  # check if coordinate is on board
            raise ValueError(Constants.COORDINATE_NOT_ON_BOARD)
        if new_piece.get_name() in self.__dict_of_pieces_on_board.keys():  # check if the piece is already board
            raise ValueError(Constants.PIECE_ALREADY_ON_BOARD)
        if self.__dict_of_cells_on_board[new_piece.get_coordinate()] is not None:  # check if the cell is occupied
            raise ValueError(Constants.OCCUPIED_CELL)
        self.__current_board[new_piece.get_coordinate()[0]][new_piece.get_coordinate()[1]] = new_piece
        # add the piece to the board
        self.__dict_of_cells_on_board[new_piece.get_coordinate()] = new_piece.get_name()  # update dict of cells
        self.__dict_of_pieces_on_board[new_piece.get_name()] = new_piece.get_coordinate()  # update dict of pieces
        return True
    # General note: if the piece is not added, the method will raise an exception and the program will shut down. Means
    # that every class that uses the board class, should handle the exception.

    def possible_moves(self, piece_to_move: Piece) -> dict[str, list[tuple[int, int]]]:
        """A method that returns a dictionary of possible moves for a  single piece.
        The keys are the moves and the values are the coordinates of the new position after the move.
        There are two kind of possible moves for a piece: 1- simple step (one step every possible direction)
        2- hop (hop over an opponent piece, as many as user wish).
        """
        possible_moves = {}
        for option in Constants.POSSIBLE_MOVES:  # iterate over the possible options for moves
            if option == Constants.SIMPLE_STEP:
                list_of_simple_step_possibility: list[tuple[int, int]] = []  # create a list for simple step possibility
                for direction, cell in self.__simple_step_directions(piece_to_move.get_coordinate()).items():
                    # iterate over the coordinates surrounding the piece
                    if cell in self.__dict_of_cells_on_board.keys() and self.__dict_of_cells_on_board[cell] is None:
                        # check if the cell is on the board and empty
                        list_of_simple_step_possibility.append(cell)
                possible_moves[Constants.SIMPLE_STEP] = list_of_simple_step_possibility  # add the list to the dict
            if option == Constants.HOP_OVER_ANOTHER_PIECE:
                hops_option = self.__find_all_hops(piece_to_move.get_coordinate(), [])
                if piece_to_move.get_coordinate() in hops_option:
                    hops_option.remove(piece_to_move.get_coordinate())  # remove the original coordinate from the list
                possible_moves[Constants.HOP_OVER_ANOTHER_PIECE] = hops_option  # add the list to the dictionary
        return possible_moves

    @staticmethod
    def __simple_step_directions(coordinate: tuple[int, int]) -> dict[str, tuple[int, int]]:
        """A private method that returns a list of possible directions for a simple step.
        The list is a list of dictionaries, where the key is the direction and the value is the new coordinate.
        Pay attention that there is a difference between the directions of the even and odd rows!"""
        #  take care of the difference between the directions of the even and odd rows, relative to the coordinate.
        offsets = {
            "even": {"ul": (-1, 0), "ur": (-1, 1), "l": (0, -1), "r": (0, 1), "dl": (1, 0), "dr": (1, 1)},
            "odd": {"ul": (-1, -1), "ur": (-1, 0), "l": (0, -1), "r": (0, 1), "dl": (1, -1), "dr": (1, 0)}
        }
        row_type = "even" if coordinate[0] % 2 == 0 else "odd"
        possible_directions = {direction: (coordinate[0] + offset[0], coordinate[1] + offset[1])
                               for direction, offset in offsets[row_type].items()}
        # create a dictionary, where the key is the direction and the value is the new coordinate
        return possible_directions

    def __hop_over_another_piece(self, current_coordinate: tuple[int, int]) -> dict[str, tuple[int, int]]:
        """A private method that returns a list of possible directions for one hop over another piece."""
        possible_hop_cells: dict[str, tuple[int, int]] = {}
        for direction, cell in self.__simple_step_directions(current_coordinate).items():
            # iterate over the neighbor cells of current coordinate.
            if cell in self.__dict_of_cells_on_board.keys() and self.__dict_of_cells_on_board[cell] is not None:
                # check if the neighbor cell is on the board and occupied by piece (make it available for hop)
                next_cell = self.__simple_step_directions(cell)[direction]
                if (next_cell in self.__dict_of_cells_on_board.keys() and self.__dict_of_cells_on_board[next_cell]
                        is None):
                    # check if the cell after the neighbor piece is on board and empty
                    possible_hop_cells[direction] = next_cell
        return possible_hop_cells

    def __find_all_hops(self, coordinate: tuple[int, int],
                        visited_coordinates: list[tuple[int, int]]) -> list[tuple[int, int]]:
        """
        This function finds all possible hop coordinates for a piece.
        It uses recursion to explore all possible paths.
        It avoids visiting the same coordinate twice to prevent infinite recursion.
        """
        if coordinate in visited_coordinates:  # if the coordinate has already been visited, return an empty list
            return []
        visited_coordinates.append(coordinate)  # add the current coordinate to the list of visited coordinates
        # get a dictionary of possible hop moves from the current coordinate
        possible_hops = self.__hop_over_another_piece(coordinate)
        # initialize a list to store all possible hop coordinates
        all_hops = [coordinate]  # initialize a list to store all possible hop coordinates
        # for each possible hop move, recursively find all possible hop coordinates
        for direction, new_coordinate in possible_hops.items():
            hops_from_new_coordinate = self.__find_all_hops(new_coordinate, visited_coordinates)
            all_hops.extend(hops_from_new_coordinate)  # add the possible hop coordinates to list of all possible hops
        return all_hops

    def move_piece(self, piece_to_move: Piece, new_coordinate: tuple[int, int]) -> bool:
        """A method that moves a piece to a new coordinate. It checks if the move is legal and updates the board."""
        possible_moves = self.possible_moves(piece_to_move)
        is_legal_move = False  # initialize a boolean variable to check if the move is legal
        for move_list in possible_moves.values():  # iterate over the possible moves for the piece
            if new_coordinate in move_list:
                is_legal_move = True
                break  # if the new coordinate is in the possible moves, the move is legal
        if is_legal_move:
            self.__current_board[piece_to_move.get_coordinate()[0]][piece_to_move.get_coordinate()[1]] = None
            # remove the piece from the board
            self.__dict_of_cells_on_board[piece_to_move.get_coordinate()] = None  # update the dict of cells to None
            piece_to_move.move(new_coordinate)  # move the piece to the new coordinate
            self.__dict_of_pieces_on_board[piece_to_move.get_name()] = new_coordinate  # update the dictionary of pieces
            self.__current_board[new_coordinate[0]][new_coordinate[1]] = piece_to_move  # add piece to board
            self.__dict_of_cells_on_board[new_coordinate] = piece_to_move.get_name()  # update the dictionary of cells
            return True
        else:
            raise ValueError(Constants.ILLEGAL_MOVE)
    # General note: if the piece is not moved, the method will raise an exception and the program will shut down. Means
    # that every class that uses the board class, should handle the exception.

    def get_cells_on_board(self) -> list[tuple[int, int]]:
        """A method that returns a list of all the cells on board (without their values and OutOfBoard cells)."""
        return list(self.__dict_of_cells_on_board.keys())

    def get_value_in_cell(self, coordinate: tuple[int, int]) -> Any:
        """A method that returns the value in a cell on the board (via dict_of_cells)."""
        if coordinate not in self.__dict_of_cells_on_board.keys():
            raise ValueError(Constants.COORDINATE_NOT_ON_BOARD)
        return self.__dict_of_cells_on_board[coordinate]

    def get_copy_of_board_data_for_gui(self) -> list[list[Any]]:
        """
        A method that returns a copy of the board data for the GUI.
        GUI is going to use this data to display the board.
        """
        return copy.deepcopy(self.__current_board)  # we use deepcopy to avoid changing the original board
