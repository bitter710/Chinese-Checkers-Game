#############################################################
# FILE : game.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: game class for chinese checkers game
#############################################################
from board import *
from piece import Piece
from player import Player
from strategy import Strategy
from constants import *
from typing import Optional, Any
import logging
import time
import os
import playsound
from gui_main import GUIMain


class Quit(Exception):
    """
    Quit game exception. Will be used when a player quits the game to the main menu.
    """


class Game:
    """
    A class used to represent a game of chinese checkers.
    It gets a dict of players and their strategies, checks it, initializes the board and runs a game.
    Game class is suitable for either human and computer players, where the computer player is using a chosen strategy,
    Chinese Checkers is a strategy board game which can be played by 2-6 players (except for 5 players).
    Every vital information about the game is stored in a log file (will be stored at the log_files directory).
    Class Game also deals with the possibility of loading a game from a log file.
    """

    def __init__(self, main_root: GUIMain, players_dict: dict[Player, Any], game_type: str,
                 loaded_game: Optional[bool], loaded_board: Optional[Board],
                 num_of_round: Optional[int], previous_id: Optional[str], player_to_continue: Optional[str]) -> None:
        """
        A constructor for Game class. Here we check the players_dict and initialize the board.
        :param players_dict: a dict of players and their strategies
        """
        self.__main_root = main_root  # keeping the main root for the gui
        self.__root = self.__main_root.get_root()  # keeping the main root for the gui
        self.__game_type = game_type  # keeping the game type
        if loaded_game is None:  # if the game is not loaded
            Game.__check_dict_helper(players_dict)  # check the players_dict in a helper method.
            # the players_dict is legal, otherwise Main and Tournament will catch the exception
            if game_type not in Constants.OPTIONS_FOR_ID:  # check if the game type is legal
                raise ValueError(Constants.ERROR_GAME_TYPE)
            self.__game_id: str = f"{int(time.time())} - {self.__game_type}"  # use a timestamp as a game identifier
            self.__players_dict = players_dict  # keeping the dict data, especially for the computer players strategies
            self.__players_list = list(players_dict.keys())  # a list of the players
            self.__board = Board()  # initialize the board
            for player_to_add in self.__players_list:
                for piece_to_add in player_to_add.get_pieces_of_player():
                    try:
                        self.__board.add_piece_to_board(piece_to_add)  # add the pieces of the players to the board
                    except ValueError:
                        raise ValueError(Constants.ERROR_ADD_PIECE)
            self.__num_of_round: int = Constants.ONE_AS_INT  # a counter for the rounds
            self.__next_player: str = self.__players_list[0].get_name()  # the first player to start the game
            self.__loaded_game: bool = False  # a flag for the loaded game
            # Start logging for this game
            self.logger, self.file_handler = self.__start_game_logging(self.__game_id, None)  # start log
            self.logger.info(f"Game {self.__game_id} has been initialized!")  # log the start of the game
            self.__initializing_data_for_loaded_game()  # initialize the data of the players and load it to log
        else:  # if the game is loaded
            self.__players_dict = players_dict
            # keeping the dict data, especially for the computer players strategies
            self.__players_list = list(players_dict.keys())  # a list of the players
            self.__board = loaded_board if loaded_board is not None else self.__board  # keeping the board
            self.__game_id = previous_id if previous_id is not None else self.__game_id  # keeping the game id
            self.logger, self.file_handler = (
                self.__start_game_logging(None, f'{self.__game_id}.log'))
            self.logger.info(f"Game {self.__game_id} has been initialized again!")  # log the start of the game
            self.__initializing_data_for_loaded_game()  # initialize the data of the players and load it to log
            self.__num_of_round = num_of_round if num_of_round is not None else self.__num_of_round
            self.__next_player = player_to_continue if player_to_continue is not None else self.__next_player
            self.__loaded_game = True  # a flag for the loaded game

    def __one_player_turn(self, player_to_play: Player, current_board: Board, counter_of_rounds: int) -> bool:
        """
        A method for a single turn of a player.
        """
        choose_another_piece = False  # a flag for choosing another piece
        while True:  # while the user has not completed a turn
            if choose_another_piece:
                choose_another_piece = False
                continue
            string_of_turn_change = (f"{player_to_play.get_name()} it's your turn!\n"
                                     f"{Constants.PICK_PIECE}")  # will be used for the gui
            self.__main_root.update_turn_label(player_to_play, string_of_turn_change)  # update the turn label in gui
            self.__main_root.start_main_loop()  # start the main loop for the gui
            selected_piece_name = self.__main_root.get_button_value()  # get the input from the user
            if selected_piece_name == Constants.QUIT_GAME:
                raise Quit(f"{Constants.GAME_OVER}, {player_to_play.get_name()} has quit the game")
            try:
                piece_to_move = Game.__check_if_piece_belongs_to_player(selected_piece_name, player_to_play)
                self.__main_root.reset_button_value()  # reset the button value in the gui
                if Game.__check_if_can_move(current_board, piece_to_move) is False:
                    self.__main_root.add_extra_message_label(Constants.CANNOT_MOVE, Constants.ERROR_COLOR)
                    continue
                while True:  # while the user doesn't choose another piece
                    try:
                        self.__main_root.add_extra_message_label(f"Round {counter_of_rounds}")
                        self.__main_root.update_turn_label(player_to_play, Constants.PICK_CELL)
                        self.__main_root.start_main_loop()  # start the main loop for the gui
                        chosen_cell = self.__main_root.get_button_value()  # get the input from the user
                        if chosen_cell == Constants.QUIT_GAME:
                            break
                        if chosen_cell == Constants.OTHER_PIECE:
                            choose_another_piece = True
                            break
                        selected_cell = Game.__check_if_cell_is_valid(chosen_cell, piece_to_move, current_board)
                        current_board.move_piece(piece_to_move, selected_cell)  # move the piece (board is updated)
                        try:
                            playsound.playsound(Constants.MOVE_SOUND)  # play a sound of moving the piece
                        except (OSError, FileNotFoundError, playsound.PlaysoundException):  # if sound error
                            pass
                        self.__main_root.set_board(current_board)  # set the board in the gui
                        self.__main_root.refresh_gui()  # refresh the gui
                        self.logger.info(f"{Constants.MOVE_INFO}{player_to_play.get_name()} moved"
                                         f" {piece_to_move.get_name()} to {selected_cell}")
                        return self.__check_for_winner(player_to_play)  # check if there is a winner
                        # and cell in addition to moving the piece and updating the board and log
                    except ValueError:
                        continue
            except ValueError:  # inform the user that the piece is invalid
                self.__main_root.add_extra_message_label(Constants.INVALID_PIECE, Constants.ERROR_COLOR)

    def __one_computer_turn(self, player_to_play: Player, current_board: Board) -> bool:
        """
        A method for a single turn of a computer player.
        """
        strategy = self.__players_dict[player_to_play]  # get the strategy of the computer player
        while True:  # while the computer player has not completed a turn
            try:
                if strategy == Constants.STRATEGY_LEVELS[0]:  # if the strategy is random
                    next_move = Strategy.get_random_coordinate(current_board, player_to_play)
                elif strategy == Constants.STRATEGY_LEVELS[1]:  # if the strategy is best move
                    next_move = Strategy.get_best_coordinate(current_board, player_to_play)
                else:  # if the strategy is master
                    next_move = Strategy.get_best_coordinate_master(current_board, player_to_play)
                current_board.move_piece(next_move[0], next_move[1])  # move the piece (board is updated)
                self.__main_root.set_board(current_board)  # set the board in the gui
                self.__main_root.refresh_gui()  # refresh the gui
                self.logger.info(f"{Constants.MOVE_INFO}{player_to_play.get_name()} moved"
                                 f" {next_move[0].get_name()} to {next_move[1]}")  # log the move
                return self.__check_for_winner(player_to_play)  # check if there is a winner
            except ValueError:
                continue  # if error occurred while moving the piece, it might happen in the strategy, so keep trying
            except TypeError:
                continue
            except IndexError:
                continue

    def __one_round(self, current_board: Board, counter_of_rounds: int, player_to_begin_with: str) -> Any:
        """
        A method for a single round of the game. Returns True if the game is over.
        """
        self.logger.info(f"Round {counter_of_rounds} has started!")  # log the start of a new round
        try:
            # find the player to begin with in the players list
            start_index = next(i for i, player in enumerate(self.__players_list)
                               if player.get_name() == player_to_begin_with)
            # create a new order of players starting with the player to begin with
            ordered_players_list = self.__players_list[start_index:] + self.__players_list[:start_index]
            for player in ordered_players_list:
                self.__main_root.add_extra_message_label(f"Round {counter_of_rounds}")
                if Constants.COMPUTER_NAME not in player.get_name():  # if the player is a human player
                    self.__main_root.refresh_gui()  # refresh the gui
                if Constants.COMPUTER_NAME in player.get_name():  # if the player is a computer player
                    if self.__one_computer_turn(player, current_board) is True:
                        return True
                else:  # if the player is a human player
                    if self.__one_player_turn(player, current_board, counter_of_rounds) is True:
                        return True
        except Quit as e:  # if the game is over
            raise Quit(e)

    def run_game(self) -> bool:
        """
        Main method for running the game. Returns the winner of the game.
        """
        self.__initialize_gui_board()  # initialize the gui board
        if self.__loaded_game is False:  # if it is a new game
            self.logger.info(Constants.START_PARTICIPANTS + self.get_names_of_players())
            if self.__check_if_only_computer_game() is False:  # if the game is not only computer players
                self.__main_root.update_message(f"{Constants.WELCOME_MESSAGE}{self.__game_type}\n"
                                                f"{Constants.GAME_ID_MESSAGE}{self.__game_id}")
            else:  # if the game is only computer players
                self.__main_root.update_message(f"{Constants.SIMULATE_GAME}")
        if self.__loaded_game is True:  # if the game is loaded
            self.logger.info(f"The game {self.__game_id} has been loaded, let's continue!")
            self.__main_root.update_message(f"The game {self.__game_id} {Constants.LOADED_CONTINUE}")  # inform the user
        self.__main_root.pack_board_in_gui_window()  # pack the board in the gui window
        game_has_ended = False  # a flag for the end of the game
        while True:  # while there is no winner
            # In games with one or more random computer players, the game should assert the computer
            if (self.__check_if_only_computer_game() is True
                    and self.__num_of_round > Constants.ROUND_LIMIT_FOR_SIMULATIONS):
                self.logger.info(f"{Constants.SIMULATED_ENDED}{Constants.ROUND_LIMIT_FOR_SIMULATIONS} rounds!")
                self.__main_root.show_error(f"{Constants.SIMULATED_ENDED}"
                                            f"{Constants.ROUND_LIMIT_FOR_SIMULATIONS} rounds!")
                self.end_game_logging()  # end the logging for the game
                self.__main_root.reset_widgets()  # reset the widgets in the gui
                raise Quit
            try:
                if self.__one_round(self.__board, self.__num_of_round, self.__next_player) is True:
                    self.logger.info(f"{Constants.ENDED_AFTER} {self.__num_of_round} rounds!")
                    score_of_players = ""
                    for player in self.__players_list:
                        self.logger.info(player.get_score_of_player())  # log the score of the players
                        score_of_players += " * " + player.get_score_of_player() + " * "
                        game_has_ended = True
                    self.__main_root.update_turn_label_with_string(score_of_players)  # print the score of the players
                    break
                self.__num_of_round += 1
            except Quit as e:  # if someone quit the game - have the ability to restart
                self.logger.info(e)
                if self.play_again_question(False) is False:  # if player quit the game and want to quit
                    raise Quit
        return game_has_ended

    @staticmethod
    def __check_dict_helper(players_dict: dict[Player, Any]) -> None:
        """
        A helper function for checking the players_dict.
        :param players_dict: a dict of players and their strategies
        """
        if len(players_dict) not in Constants.OPTIONS_FOR_GAME:  # check if the number of players is legal
            raise ValueError(Constants.PARTICIPANTS_ERROR)
        cells_of_players_set = set()  # a set of the cells of the players for check
        names_of_players_set = set()  # a set of the names of the players for check
        if len(players_dict) == Constants.OPTIONS_FOR_GAME[0]:  # if the number of players is 2:
            num_of_pieces_to_check = Constants.ALTERNATE_NUMBER_OF_PIECES  # the number of pieces for each player is 15
            target_triangle = Constants.TARGET_TRIANGLE_FOR_NUM_OF_PLAYERS[Constants.OPTIONS_FOR_GAME[0]]
        elif len(players_dict) == Constants.OPTIONS_FOR_GAME[1]:  # if the number of players is 3:
            num_of_pieces_to_check = Constants.DEFAULT_NUMBER_OF_PIECES  # the number of pieces for each player is 10
            target_triangle = Constants.TARGET_TRIANGLE_FOR_NUM_OF_PLAYERS[Constants.OPTIONS_FOR_GAME[1]]
        elif len(players_dict) == Constants.OPTIONS_FOR_GAME[2]:  # if the number of players is 4:
            num_of_pieces_to_check = Constants.DEFAULT_NUMBER_OF_PIECES
            target_triangle = Constants.TARGET_TRIANGLE_FOR_NUM_OF_PLAYERS[Constants.OPTIONS_FOR_GAME[2]]
        else:  # if the number of players is 6:
            num_of_pieces_to_check = Constants.DEFAULT_NUMBER_OF_PIECES
            target_triangle = Constants.TARGET_TRIANGLE_FOR_NUM_OF_PLAYERS[Constants.OPTIONS_FOR_GAME[3]]
        for key, value in players_dict.items():
            if key.get_color() not in Constants.COLORS_IN_GAME:  # check if the color of the player is legal
                raise ValueError(Constants.COLOR_ERROR)
            if Constants.COMPUTER_NAME in key.get_name():  # check if the player is a computer player
                if value not in Constants.STRATEGY_LEVELS:  # check if the strategy level is legal
                    raise ValueError(Constants.STRATEGY_ERROR)
            if Constants.COMPUTER_NAME not in key.get_name():  # check if the player is a human player
                if value is not None:  # check if the strategy is None
                    raise ValueError(Constants.NONE_FOR_HUMAN_ERROR)
            if value is not None:  # if it is a computer player
                if Constants.COMPUTER_NAME not in key.get_name():
                    raise ValueError(Constants.COMPUTER_NAME_ERROR)
            if len(key.get_pieces_of_player()) != num_of_pieces_to_check:
                # check if the number of pieces for each player is legal
                raise ValueError(Constants.NUM_OF_PIECES_ERROR)
            if key.get_target_triangle() not in target_triangle:
                # check if the target triangle for each player is legal
                raise ValueError(Constants.TARGET_TRIANGLE_ERROR + str(target_triangle))
            if key.check_if_all_pieces_in_home_cells() is False:  # check if all the pieces are in the home cells
                raise ValueError(Constants.PIECES_IN_HOME_CELLS_ERROR)
            for i in key.get_pieces_of_player():  # check if the pieces of the player are legal
                cell = i.get_coordinate()
                name = i.get_name()
                if cell in cells_of_players_set or name in names_of_players_set:  # check if cells and names are legal
                    raise ValueError(Constants.SAME_HOME_CELLS_ERROR)
                else:
                    cells_of_players_set.add(cell)
                    names_of_players_set.add(name)

    @staticmethod
    def __start_game_logging(game_id: Optional[str], existing_log_file: Optional[str])\
            -> tuple[logging.Logger, logging.FileHandler]:
        """
        A static method for starting the logging for the game. If the game is loaded, the existing log file is used.
        """
        # format the log messages
        formatter = logging.Formatter(Constants.LOGGER_FORMAT)
        log_directory = Constants.LOG_FILE_PATH  # the path for the log files

        # Check if the directory exists and create it if it doesn't
        if not os.path.exists(log_directory):
            os.makedirs(log_directory)

        if existing_log_file is None:
            log_file_path = os.path.join(log_directory, f'{game_id}.log')  # Create a new log file for each game
        else:
            log_file_path = os.path.join(log_directory, existing_log_file)  # Open the existing log file in append mode
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setFormatter(formatter)
        logger = logging.getLogger(__name__)  # get the logger
        logger.setLevel(logging.INFO)
        logger.addHandler(file_handler)
        return logger, file_handler

    def end_game_logging(self) -> None:
        """
        A method for ending the logging for the game.
        """
        self.logger.removeHandler(self.file_handler)  # remove the file handler

    @staticmethod
    def __check_if_piece_belongs_to_player(piece_name: str, player: Player) -> Piece:
        """
        A method for checking if the piece belongs to the player.
        """
        for i in player.get_pieces_of_player():
            if i.get_name() == piece_name:
                return i  # if the piece belongs to the player
        raise ValueError(Constants.INVALID_PIECE)

    @staticmethod
    def __check_if_cell_is_valid(cell: str, piece_to_move: Piece, current_board: Board) -> tuple[int, int]:
        """
        A method for checking if the cell is valid.
        """
        try:
            cell = cell.replace("(", "").replace(")", "")  # remove the parentheses
            cell_tuple = tuple(map(int, cell.split(", ")))  # convert the input to a tuple of integers
            if len(cell_tuple) != Constants.LENGTH_OF_COORDINATE:  # check if the length of the tuple is 2
                raise ValueError(Constants.INVALID_CELL)
        except ValueError:
            raise ValueError(Constants.INVALID_CELL)
        for j in current_board.possible_moves(piece_to_move).values():  # iterate simple step and hop moves
            for coord in j:  # iterate the possible cells
                if cell_tuple == coord:
                    return coord
        raise ValueError(Constants.INVALID_INPUT)

    def get_names_of_players(self) -> str:
        """
        A method for getting the names of the players.
        """
        names_of_players = []
        for player in self.__players_list:
            names_of_players.append(player.get_name())  # get the names of the players
        return ', '.join(names_of_players)  # return the names of the players as a string

    def __check_for_winner(self, player: Player) -> bool:
        """
        A method for checking if there is a winner.
        """
        if player.is_player_win():
            self.__main_root.update_message(f"Congratulation! {player.get_name()} is the winner!\n"
                                            f"Game has ended after {self.__num_of_round} rounds!\n"
                                            f"{Constants.GAME_ID_MESSAGE}{self.__game_id}\n{Constants.SAVED_IN_LOG}")
            self.logger.info(f"Congratulation! {player.get_name()} is the winner!")
            for i in self.__players_list:
                if i != player:
                    i.increment_losses()  # increment the losses of the other players
            return True
        return False

    @staticmethod
    def __check_if_can_move(curr_board: Board, piece_to_move: Piece) -> bool:
        """
        This method checks if the piece can move somewhere.
        """
        for j in curr_board.possible_moves(piece_to_move).values():  # checking either hop or simple step
            if len(j) > 0:  # if there are possible cells to move
                return True
        return False

    def restart_game(self) -> None:
        """
        A method for resetting the game.
        """
        self.end_game_logging()  # end the logging for the game
        for player in self.__players_list:
            player.reset_pieces_for_next_game()  # reset the pieces of the players
        self.__main_root.reset_widgets()  # reset the widgets in the gui
        game = Game(self.__main_root, self.__players_dict, self.__game_type, None, None,
                    None, None, None)
        game.run_game()  # restart the game by initializing a new game and running it

    def play_again_question(self, game_has_ended: bool) -> bool:
        """
        A method for asking the user if they want to play again.
        """
        while True:  # while the user doesn't choose a valid option
            if game_has_ended is False:  # if the game has not ended, someone quit the game.
                self.__main_root.update_message(Constants.LOST_DATA_RESTART)
                # inform the user that the current game data won't be loaded if restart
            self.__main_root.add_extra_message_label(Constants.RESTART_GAME)  # update the message in the gui
            self.__main_root.update_button_in_gui(["yes", "no"])  # update the buttons in the gui
            self.__main_root.start_main_loop()  # start the main loop for the gui
            answer = self.__main_root.get_button_value()  # get the input from the user
            if answer == Constants.YES:
                if game_has_ended is False:
                    self.logger.info(f"The game {self.__game_id} has ended without a result!")  # log the end
                self.restart_game()
            if answer == Constants.NO:
                if game_has_ended is True:  # if the game has ended
                    self.logger.info(f"The game {self.__game_id} has ended!")  # log the end of the game
                if game_has_ended is False:  # if the game has not ended, someone quit the game
                    self.logger.info(f"The game {self.__game_id} "  # log the quit of the game
                                     f"{Constants.QUIT_IN_ROUND}{self.__num_of_round}!")
                    self.logger.info(f"The game {self.__game_id} can be loaded in the future!")
                self.end_game_logging()  # end the logging for the game
                for player in self.__players_list:
                    player.reset_pieces_for_next_game()  # reset the pieces of the players
                self.__main_root.reset_widgets()  # reset the widgets in the gui
                self.__main_root.show_message("Save id", f"{Constants.SAVE_GAME_MESSAGE}{self.__game_id}.log")
                return False
            else:  # if the user doesn't choose a valid option
                continue

    def __initializing_data_for_loaded_game(self) -> None:
        """
        A method for initializing the data of the players and load it to log.
        Will be shown in the log file, in order to use it un the future.
        """
        dict_for_next_use = {}
        if len(self.__players_list) == Constants.OPTIONS_FOR_GAME[0]:  # if the number of players is 2:
            num_of_pieces = Constants.ALTERNATE_NUMBER_OF_PIECES
        else:  # if the number of players is 3, 4 or 6:
            num_of_pieces = Constants.DEFAULT_NUMBER_OF_PIECES
        for player in self.__players_list:
            # creating a list of name, color, number of pieces, home triangle, strategy and game type
            list_of_data_for_player = [player.get_name(), player.get_color(),
                                       num_of_pieces, player.get_home_triangle(),
                                       self.__players_dict[player], self.__game_type]
            dict_for_next_use[player.get_name()] = list_of_data_for_player
        self.logger.info(f"{Constants.DATA_FOR_NEXT_USE}{dict_for_next_use}")

    def __check_if_only_computer_game(self) -> bool:
        """
        A method for checking if the game is only computer players.
        """
        for player in self.__players_list:
            if Constants.COMPUTER_NAME not in player.get_name():
                return False
        return True

    def get_winner(self) -> Any:
        """
        A method for getting the winner of the game.
        """
        for player in self.__players_list:  # iterate the players
            if player.is_player_win(True):  # if the player is the winner (only for checking, we are not recounting win)
                return player
        return None

    def get_game_id(self) -> str:
        """
        A method for getting the game id.
        """
        return self.__game_id

    def __initialize_gui_board(self) -> None:
        """
        A method for initializing the gui board.
        """
        self.__main_root.reset_widgets()  # reset the widgets in the gui
        self.__main_root.set_board(self.__board)  # set the board in the main root
