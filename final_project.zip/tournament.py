#############################################################
# FILE : tournament.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: tournament class for chinese checkers game
#############################################################
from input_from_user_helper import InputFromUser
from game import *
from constants import *
import logging
import time


class Tournament:
    """
    A class representing a tournament of chinese checkers game. Can create a new tournament of the game,
    with two semi-finals and a final. All data will be stored in a log file.
    """

    def __init__(self, main_root: GUIMain, num_of_players: int):
        """
        A constructor for a tournament object.
        """
        self.__main_root = main_root  # root of the game
        self.__tournament_id: str = f"{int(time.time())} - Tournament"  # use a timestamp as a tournament identifier
        self.__list_of_players: list[Player] = []  # list of players for the tournament
        self.__winner_of_semi_final_A: Optional[Player] = None
        self.__winner_of_semi_final_B: Optional[Player] = None
        self.__winner_of_final: Optional[Player] = None
        self.__logger, self.__file_handler = self.__start_tournament_logging(self.__tournament_id)  # start log
        if num_of_players < Constants.MIN_NUM_OF_PLAYERS or num_of_players > Constants.MAX_NUM_OF_PLAYERS:
            raise ValueError(f"{Constants.INVALID_NUM_OF_PLAYERS}{num_of_players}")  # invalid number of players
        else:  # if the number of players is valid, inform the user and continue initializing the tournament
            self.__main_root.show_message("Pay Attention",
                                          f"{Constants.GET_STARTED_WITH_TOURNAMENT}{self.__tournament_id}")
            self.__num_of_players: int = num_of_players
            self.__num_of_players_for_semi_a: int = num_of_players // Constants.SEMI_DIVIDER  # divide the players
            self.__num_of_players_for_semi_b: int = num_of_players - self.__num_of_players_for_semi_a
            self.__logger.info(f"{Constants.TOTAL_NUMBER_OF_PLAYERS_MESSAGE}{num_of_players}")
            self.__logger.info(f"{Constants.NUM_OF_PLAYERS_FOR_SEMI_A_MESSAGE}{self.__num_of_players_for_semi_a}")
            self.__logger.info(f"{Constants.NUM_OF_PLAYERS_FOR_SEMI_B_MESSAGE}{self.__num_of_players_for_semi_b}")

    @staticmethod
    def __start_tournament_logging(tournament_id: str) -> tuple[logging.Logger, logging.FileHandler]:
        """
        A method to start logging the tournament.
        """
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(message)s')  # set the format of the log
        log_directory = Constants.LOG_FILE_PATH  # set the log directory
        if not os.path.exists(log_directory):  # Check if the directory exists and create it if it doesn't
            os.makedirs(log_directory)
        log_file_path = os.path.join(log_directory, f'{tournament_id}.log')  # Create a new log file for each tournament
        file_handler = logging.FileHandler(log_file_path)  # create a file handler
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)  # set the format of the file handler
        logger = logging.getLogger(tournament_id)
        logger.setLevel(logging.INFO)
        logger.addHandler(file_handler)
        return logger, file_handler

    def __end_tournament_logging(self) -> None:
        """
        A method for ending the logging for the game.
        """
        self.__logger.info(Constants.STOP_LOGGING)  # stop logging info to log file
        self.__logger.removeHandler(self.__file_handler)

    def __load_players_for_both_semis(self) -> tuple[dict[Player, Any], dict[Player, Any]]:
        """
        A method to load the players of the tournament.
        """
        list_of_names: list[str] = []  # list of names
        dict_of_players_semi_a: dict[Player, Any] = {}
        dict_of_players_semi_b: dict[Player, Any] = {}
        for i in range(Constants.TWO_AS_INT):  # for both semi-finals
            counter_of_players = 0  # counter of players for each semi-final
            available_colors: list[str] = Constants.COLORS_IN_GAME.copy()  # available colors for each semi-final
            if i == 0:  # for semi-final A
                num_of_players = self.__num_of_players_for_semi_a
                current_semi_final = Constants.SEMI_FINAL_A
            else:  # for semi-final B
                num_of_players = self.__num_of_players_for_semi_b
                current_semi_final = Constants.SEMI_FINAL_B
            if num_of_players == Constants.TWO_AS_INT:  # if there are only 2 players
                num_of_pieces_for_player = Constants.ALTERNATE_NUMBER_OF_PIECES  # set the number of pieces to 15
            else:
                num_of_pieces_for_player = Constants.DEFAULT_NUMBER_OF_PIECES  # set the number of pieces to 10
            while counter_of_players < num_of_players:  # while the num of players is not reached
                self.__main_root.add_extra_message_label(f"{Constants.SETTING_PLAYERS_FOR_SEMI}"
                                                         f"{current_semi_final}\n{Constants.NEXT_PLAYER}")  # info label
                list_of_data_for_single_player =\
                    (InputFromUser.getting_input_for_a_single_player(self.__main_root,
                                                                     self.__num_of_players_for_semi_a,
                                                                     available_colors, list_of_names))
                if list_of_data_for_single_player == QuitGame:
                    raise Quit
                if list_of_data_for_single_player == PreviousPage:
                    raise Quit
                # set home triangle for each player (according to the number of players)
                home_triangle = \
                    Constants.HOME_TRIANGLE_FOR_NUM_OF_PLAYERS[num_of_players][counter_of_players]
                # create a new player
                try:
                    player = Player(list_of_data_for_single_player[1])  # create a new player with its name
                    player.set_color(list_of_data_for_single_player[2])  # set the player color
                    player.set_number_of_pieces(num_of_pieces_for_player)  # set the number of pieces
                    player.set_home_cells(home_triangle)  # set the home triangle for the player
                    if i == 0:  # for semi-final A
                        dict_of_players_semi_a[player] = list_of_data_for_single_player[3]
                    else:  # for semi-final B
                        dict_of_players_semi_b[player] = list_of_data_for_single_player[3]
                    # add the player to the dictionary with strategy
                    counter_of_players += 1  # successful setting, continue to the next player
                except Exception as e:
                    self.__main_root.show_error(str(e))  # show error message and try again
                if counter_of_players == num_of_players:  # all the players have been set successfully
                    break  # break the loop
        return dict_of_players_semi_a, dict_of_players_semi_b

    def __run_semi_finals(self) -> dict[Player, Any]:
        """
        A method to run the semi-finals of the tournament. Returns the winners of the semi-finals.
        """
        while True:
            try:  # dealing with exceptions during the loading of the players
                dict_of_players_semi_a, dict_of_players_semi_b = self.__load_players_for_both_semis()
                if (len(dict_of_players_semi_a) < Constants.TWO_AS_INT
                        or len(dict_of_players_semi_b) < Constants.TWO_AS_INT):
                    raise Quit  # if the number of players is less than 2, quit the tournament (should be at least 2)
                else:  # if the number of players is valid
                    break  # break the loop if the number of players is valid
            except Quit:  # if for some reason the dict is empty or user pressed previous page
                raise Quit
            except Exception as e:
                self.__main_root.show_error(str(e))  # show error message and try again
                raise Quit
        # if players have been set successfully, continue to the semi-finals
        self.__list_of_players = list(dict_of_players_semi_a.keys()) + list(dict_of_players_semi_b.keys())
        dict_of_winners: dict[Player, Any] = {}
        for i in range(Constants.TWO_AS_INT):  # for both semi-finals
            if i == 0:
                self.__main_root.reset_widgets()  # reset the widgets of the main root
                semi_final = Game(self.__main_root, dict_of_players_semi_a, Constants.SEMI_FINAL_A, None,
                                  None, None, None, None)
                cur_semi_final = Constants.SEMI_FINAL_A  # create a game for semi A
            else:
                semi_final = Game(self.__main_root, dict_of_players_semi_b, Constants.SEMI_FINAL_B, None,
                                  None, None, None, None)
                cur_semi_final = Constants.SEMI_FINAL_B  # create a game for semi B
            self.__logger.info(f"{cur_semi_final} started")
            self.__logger.info(f"{Constants.PARTICIPANTS_ARE}{semi_final.get_names_of_players()}")
            self.__logger.info(f"{Constants.GETTING_DATA_OF_GAME_BY_GAME_ID}{semi_final.get_game_id()}")
            semi_final.run_game()  # run the semi-final
            winner = semi_final.get_winner()  # get the winner of the semi-final
            self.__logger.info(f"{cur_semi_final} ended")
            if isinstance(winner, Player):  # if the winner is a player (if there is a winner)
                current_dict_of_players = dict_of_players_semi_a if i == 0 else dict_of_players_semi_b
                for key, value in current_dict_of_players.items():
                    key.reset_pieces_for_next_game()  # reset the pieces of the players for the next game
                    if key.get_name() == winner.get_name():
                        dict_of_winners[key] = value  # setting the strategy of the winners of semi-finals
                if i == 0:
                    self.__winner_of_semi_final_A = winner  # setting the winner of semi-final A
                else:
                    self.__winner_of_semi_final_B = winner
                self.__logger.info(f"{cur_semi_final} winner is: {winner.get_name()}")
                self.__helper_for_stopping_main_event_loop(semi_final.get_game_id(), winner.get_name())
                # stop the main event loop - show the winner of the semi-final
            semi_final.end_game_logging()  # end the logging for the semi-final
        if self.__winner_of_semi_final_A is not None and self.__winner_of_semi_final_B is not None:
            self.__logger.info(f"{Constants.PREPARE_FOR_THE_BIG_FINAL} {self.__winner_of_semi_final_A.get_name()}"
                               f" vs {self.__winner_of_semi_final_B.get_name()}")
        return dict_of_winners  # return the winners of the semi-finals with their strategies

    def run_tournament(self) -> None:
        """
        A method to run the final of the tournament. Returns the winner of the final.
        """
        self.__main_root.reset_widgets()  # reset the widgets of the main root
        while True:
            try:
                dict_of_winners = self.__run_semi_finals()
            except Quit:  # if user stopped in the middle of the game or in the middle of the tournament or pressed p
                self.__end_tournament_logging()  # end the logging for the tournament
                raise Quit  # will be quited to the num of players menu
            except Exception as e:
                self.__main_root.show_error(str(e))  # show error message and try again
                return
            counter_of_player = 0  # now, we set the final game
            self.__main_root.show_message("Pay Attention", Constants.COLORS_MESSAGE)
            try:
                for key, value in dict_of_winners.items():  # for the finals, we change the colors and home cells
                    key.set_number_of_pieces(Constants.ALTERNATE_NUMBER_OF_PIECES)  # set to alt number of pieces 15
                    key.set_home_cells(Constants.HOME_TRIANGLE_FOR_NUM_OF_PLAYERS
                                       [Constants.TWO_AS_INT][counter_of_player])
                    key.set_color(Constants.FINAL_COLORS[counter_of_player])
                    if value == Constants.LEVEL_3:  # if a computer used the third level of strategy in semi
                        dict_of_winners[key] = Constants.LEVEL_2  # change the strategy to level 2
                    counter_of_player += 1
            except Exception as e:
                self.__main_root.show_error(str(e))  # show error message and try again
                continue  # try again the tournament
            try:
                final = Game(self.__main_root, dict_of_winners, Constants.FINAL,
                             None, None, None, None, None)
            except Exception as e:  # if there is an error while setting the final game
                self.__main_root.show_error(str(e))  # show error message and try again
                continue  # try again the tournament
            self.__logger.info(f"{Constants.FINAL} started")
            self.__logger.info(f"{Constants.PARTICIPANTS_ARE}{final.get_names_of_players()}")
            self.__logger.info(f"{Constants.GETTING_DATA_OF_GAME_BY_GAME_ID}{final.get_game_id()}")
            try:
                self.__main_root.reset_widgets()  # reset the widgets of the main root
                final.run_game()  # run the final
            except Quit:  # if user stopped in the middle of the game
                self.__end_tournament_logging()  # end the logging for the tournament
                raise Quit
            winner = final.get_winner()  # get the winner of the final
            self.__logger.info(f"{Constants.FINAL} ended")
            if isinstance(winner, Player):
                self.__winner_of_final = winner
                self.__logger.info(f"{Constants.FINAL} winner is: {winner.get_name()}")
                self.__helper_for_stopping_main_event_loop(final.get_game_id(), winner.get_name())
                # stop the main event loop
            for player in self.__list_of_players:
                player.reset_pieces_for_next_game()  # reset the pieces of the players for the next game
                self.__logger.info(f"{Constants.SCORE_LOGGER} {player.get_score_of_player()}")  # log the score
            self.__main_root.reset_widgets()  # reset the widgets of the main root
            final.end_game_logging()  # end the logging for the final
            self.__end_tournament_logging()  # end the logging for the tournament
            return

    def __helper_for_stopping_main_event_loop(self, game_id: str, winner: str) -> None:
        """
        A helper method for stopping the main event loop.
        """
        self.__main_root.update_message(f"{game_id} winner is: {winner}.")
        self.__main_root.update_button_in_gui([Constants.PRESS_HERE_TO_CONTINUE])
        self.__main_root.start_main_loop()
        while True:
            input_from_user = self.__main_root.get_input_from_user()
            if input_from_user == Constants.PREVIOUS_CHAR:
                return
            elif input_from_user == Constants.QUIT_CHAR:
                self.__main_root.reset_widgets()  # reset the widgets of the main root
                raise Quit
            else:
                continue
