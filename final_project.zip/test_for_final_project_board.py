#############################################################
# FILE : test_for_final_project_board.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: test for board class for chinese checkers game
#############################################################

import pytest
from piece import Piece
from board import Board, OutOfBoard


def test_cells_on_board():
    board = Board()
    assert board.get_cells_on_board() == [(0, 6), (1, 6), (1, 7), (2, 5), (2, 6), (2, 7), (3, 5), (3, 6), (3, 7),
                                          (3, 8), (4, 0), (4, 1), (4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (4, 7),
                                          (4, 8), (4, 9), (4, 10), (4, 11), (4, 12), (5, 1), (5, 2), (5, 3), (5, 4),
                                          (5, 5), (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11), (5, 12), (6, 1),
                                          (6, 2), (6, 3), (6, 4), (6, 5), (6, 6), (6, 7), (6, 8), (6, 9), (6, 10),
                                          (6, 11), (7, 2), (7, 3), (7, 4), (7, 5), (7, 6), (7, 7), (7, 8), (7, 9),
                                          (7, 10), (7, 11), (8, 2), (8, 3), (8, 4), (8, 5), (8, 6), (8, 7), (8, 8),
                                          (8, 9), (8, 10), (9, 2), (9, 3), (9, 4), (9, 5), (9, 6), (9, 7), (9, 8),
                                          (9, 9), (9, 10), (9, 11), (10, 1), (10, 2), (10, 3), (10, 4), (10, 5),
                                          (10, 6), (10, 7), (10, 8), (10, 9), (10, 10), (10, 11), (11, 1), (11, 2),
                                          (11, 3), (11, 4), (11, 5), (11, 6), (11, 7), (11, 8), (11, 9), (11, 10),
                                          (11, 11), (11, 12), (12, 0), (12, 1), (12, 2), (12, 3), (12, 4), (12, 5),
                                          (12, 6), (12, 7), (12, 8), (12, 9), (12, 10), (12, 11), (12, 12), (13, 5),
                                          (13, 6), (13, 7), (13, 8), (14, 5), (14, 6),
                                          (14, 7), (15, 6), (15, 7), (16, 6)]
    for i in range(len(board.get_cells_on_board())):
        assert type(board.get_cells_on_board()[i]) != OutOfBoard, 'All cells should be on the board None or String'
    if len(board.get_cells_on_board()) == 121:
        assert True, 'There are 121 cells on the board (without the out of board cells)'


def test_add_piece_to_board():
    board1 = Board()
    piece = Piece('Y', 1, (0, 6))
    board1.add_piece_to_board(piece)
    assert board1.get_value_in_cell((0, 6)) == "Y01", 'The value in cell (0,6) should be Y1'
    piece = Piece('M', 7, (8, 5))
    board1.add_piece_to_board(piece)
    assert board1.get_value_in_cell((8, 5)) == "M07", 'The value in cell (8,5) should be M7'
    piece = Piece('R', 3, (819, 15767))
    with pytest.raises(ValueError):
        board1.add_piece_to_board(piece), "The coordinate is out of board, should raise ValueError"
    piece = Piece('R', 3, (8, 5))
    with pytest.raises(ValueError):
        board1.add_piece_to_board(piece), "The cell is already occupied, should raise ValueError"
    piece = Piece('Y', 1, (8, 6))
    with pytest.raises(ValueError):
        board1.add_piece_to_board(piece), "piece with the same name already exists, should raise ValueError"
    piece = Piece('T', 2, (0, 0))
    with pytest.raises(ValueError):
        board1.add_piece_to_board(piece), "coordinate is OutOfBoard, should raise ValueError"


def test_possible_moves_and_move_piece():
    board = Board()
    piece_p1 = Piece('P', 1, (10, 4))
    board.add_piece_to_board(piece_p1)
    piece_p5 = Piece('P', 5, (6, 5))
    board.add_piece_to_board(piece_p5)
    piece_p7 = Piece('P', 7, (9, 6))
    board.add_piece_to_board(piece_p7)
    piece_p8 = Piece('P', 8, (9, 5))
    board.add_piece_to_board(piece_p8)
    piece_p9 = Piece('P', 9, (7, 5))
    board.add_piece_to_board(piece_p9)
    piece_f9 = Piece('F', 9, (8, 4))
    board.add_piece_to_board(piece_f9)
    piece_q9 = Piece('Q', 9, (11, 8))
    board.add_piece_to_board(piece_q9)
    piece_r3 = Piece('R', 3, (7, 8))
    board.add_piece_to_board(piece_r3)
    piece_s1 = Piece('S', 1, (3, 5))
    board.add_piece_to_board(piece_s1)
    piece_s2 = Piece('S', 2, (4, 4))
    board.add_piece_to_board(piece_s2)
    piece_y7 = Piece('Y', 7, (11, 7))
    board.add_piece_to_board(piece_y7)
    piece_k7 = Piece('K', 7, (6, 1))
    board.add_piece_to_board(piece_k7)
    piece_n2 = Piece('N', 2, (8, 10))
    board.add_piece_to_board(piece_n2)
    piece_n3 = Piece('N', 3, (8, 9))
    board.add_piece_to_board(piece_n3)

    assert (board.possible_moves(piece_p1) ==
            {'simple step': [(9, 4), (10, 3), (10, 5), (11, 4), (11, 5)],
             'hop over another piece': [(8, 5), (6, 4), (6, 6), (8, 3), (10, 6), (12, 7), (10, 8)]}), \
            "the possible moves for piece_p1 are: simple step to (9, 4), (10, 3), (10, 5), (11, 4), (11, 5) (5 options,\
            because P8 is blocking the way to (9, 5)). \
            hop over another piece to: \
            (8, 5) jump ur over P8. \
            (6, 4): after jumping to (8,5), you can jump ul to (6,4). \
            (6, 6): after jumping to (6,4), you can jump right to (6,6). \
            (8, 3): after jumping to (8, 5), you can jump left to (8,3) \
            (10, 6): after jumping to (8, 5), you can jump dr to (10, 6) \
            (12, 7): after jumping to (10, 6), you can jump dr to (12, 7) \
            (10, 8): after jumping to (12, 7), you can jump ur to (10, 8)"
    assert board.possible_moves(piece_s2) == {'simple step': [(4, 3), (4, 5), (5, 4), (5, 5)],
                                             'hop over another piece': [(2, 5)]}, \
            "the possible moves for piece_s2 are: simple step to (4, 3), (4, 5), (5, 4), (5, 5) (4 options). \
             because S1 is blocking the way to (3, 5) and (3, 4) is OutOfBoard, \
              the only hop over another piece is to (2, 5)"
    assert board.possible_moves(piece_p9) == {'simple step': [(6, 4), (7, 4), (7, 6), (8, 5)],
                                              'hop over another piece': [(5, 6), (9, 4), (11, 5)]}, \
            "the possible moves for piece_p9 are: simple step to (6, 4), (7, 4), (7, 6), (8, 5) (4 options). \
            because P5 is blocking the way to (6, 5) and F9 is blocking the way to (8, 4). \
            hop over another piece to: \
            (5, 6): jump ur over P5. \
            (9, 4): jump dl over F9. \
            (11, 5): after jumping to (9, 4), you can jump dr to (11, 5)"
    assert board.possible_moves(piece_k7) == {'simple step': [(5, 1), (5, 2), (6, 2), (7, 2)],
                                             'hop over another piece': []}, \
        "two options are blocked since they are OutOfBoard. no hops available."
    assert board.possible_moves(piece_n2) == {'simple step': [(7, 10), (7, 11), (9, 10), (9, 11)],
                                             'hop over another piece': [(8, 8), (6, 7)]}, \
            "the possible moves for piece_n2 are: simple step to (7, 10), (7, 11), (9, 10), (9, 11) (4 options). \
            since N3 is blocking the way to (8, 9) and (8, 11) is OutOfBoard, \
            hop is available to (8, 8) and if needed, ul to (6, 7) (jumping over R3)"

    assert board.move_piece(piece_p1, (10, 3)) is True, "piece_p1 should move l to (10, 3)"
    assert board.get_value_in_cell((10, 3)) == "P01", "the value in cell (10, 3) should be P1"
    assert board.get_value_in_cell((10, 4)) is None, "the value in cell (10, 4) should be None"
    board.move_piece(piece_p1, (10, 4))  # move back to original position

    assert board.move_piece(piece_p9, (11, 5)) is True, "P9 should hop to (11, 5)"
    assert board.get_value_in_cell((11, 5)) == "P09", "the value in cell (11, 5) should be P9"
    assert board.get_value_in_cell((9, 4)) is None, "the value in cell (9, 4) should be None"
    assert board.get_value_in_cell((7, 5)) is None, "the value in cell (7, 5) should be None"
    board.move_piece(piece_p9, (7, 5))  # move back to original position

    with pytest.raises(ValueError):
        board.move_piece(piece_s2, (3, 4)), "S2 should not be able to move to (3, 4) - OutOfBoard"
    with pytest.raises(ValueError):
        board.move_piece(piece_s2, (3, 5)), "S2 should not be able to move to (3, 5) - blocked by S1"
    with pytest.raises(ValueError):
        board.move_piece(piece_s2, (19, 182)), "S2 should not be able to move - not in board"
    with pytest.raises(ValueError):
        board.move_piece(piece_s2, (1, 2, 5)), "S2 should not be able to move - invalid coordinate"

















