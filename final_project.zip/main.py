#############################################################
# FILE : main.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: main class for chinese checkers game
#############################################################
from tournament import *
from loader_menu import *
from gui_main import GUIMain
from input_from_user_helper import InputFromUser
from constants import *
import argparse


class MainMenu:
    """
    Main menu class for chinese checkers game. We have two main options: game mode and tournament menu.
    In the game mode, user can get data and board status, start a new game or
     load a previous game (continue a game using a game ID,
    even 1 year ago, as long as the file exists in log_files folder).
    In the tournament menu, user can start a new tournament or get
    previous data of a tournament (winner of the tournament, score of each participant, etc.).
    """

    @staticmethod
    def main_menu(main_root: GUIMain) -> None:
        """
        Main menu options: game mode, play a tournament, quit.
        """
        while True:
            try:  # For GUI - reset the value of the button, update the message label,
                # update the buttons and start mainloop
                (GUIMain.helper_for_setting_gui_for_next_page
                 (main_root, f"{Constants.WELCOME_MSG}\n\n{Constants.WOULD_LIKE_TO_DO}",
                  [Constants.GAME_MODE, Constants.TOURNAMENT_MODE, Constants.QUIT]))
                pick_option = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
                if pick_option == Constants.GAME_MODE_INPUT_RATE:
                    return_value = MainMenu.__game_mode(main_root)
                    if return_value == QuitGame:
                        main_root.get_root().destroy()  # quit the GUI
                        break
                elif pick_option == Constants.TOURNAMENT_MODE_INPUT_RATE:
                    return_value = MainMenu.__tournament(main_root)
                    if return_value == QuitGame:
                        main_root.get_root().destroy()
                        break
                elif pick_option == Constants.QUIT_BOTTOM:  # quit
                    main_root.get_root().destroy()  # quit the GUI
                    break
                else:
                    main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again
            except Exception as e:
                main_root.show_error(str(e))  # other errors - will be shown in the GUI message box. Try again.

    @staticmethod
    def __game_mode(main_root: GUIMain) -> Any:
        """
        Game mode options: get data, start new game, load previous game.
        """
        while True:
            # For GUI - reset the value of the button, update the message label,
            # update the buttons and start mainloop
            (GUIMain.helper_for_setting_gui_for_next_page
             (main_root, f"{Constants.GAME_MENU}\n\n{Constants.WOULD_LIKE_TO_DO}",
              [Constants.GET_PREVIOUS_DATA, Constants.START_NEW_GAME,
               Constants.CONTINUE_LOADED_GAME,
               Constants.PREVIOUS, Constants.QUIT]))
            pick_option = main_root.get_button_value()
            if pick_option == Constants.GET_PREVIOUS_DATA_INPUT_RATE:
                return_value = MainMenu.__get_data_mode(main_root)
                if return_value == QuitGame:
                    return QuitGame
            elif pick_option == Constants.START_NEW_GAME_INPUT_RATE:
                return_value = MainMenu.__start_new_game(main_root)
                if return_value == QuitGame:
                    return QuitGame
                if return_value == PreviousPage:
                    continue  # if game has ended and user refused to play again, go back to previous page (game menu)
            elif pick_option == Constants.CONTINUE_LOADED_GAME_INPUT_RATE:
                return_value = MainMenu.__load_previous_game(main_root)
                if return_value == QuitGame:
                    return QuitGame
                if return_value == PreviousPage:
                    continue
            elif pick_option == Constants.PREVIOUS_BOTTOM:
                break  # go back to previous page (main menu)
            elif pick_option == Constants.QUIT_BOTTOM:
                return QuitGame
            else:
                main_root.show_error(Constants.INVALID_INPUT)

    @staticmethod
    def __get_data_mode(main_root: GUIMain) -> Any:
        """
        Data mode options: get winner, get single player data, get entire data.
        """
        while True:
            # For GUI - reset the value of the button, update the message label,
            # update the buttons and start mainloop
            main_root.remove_insertion_option()
            (GUIMain.helper_for_setting_gui_for_next_page
             (main_root, f"{Constants.DATA_MENU}\n\n{Constants.WOULD_LIKE_TO_DO}",
              [Constants.DATA_GET_WINNER, Constants.DATA_GET_SINGLE_PLAYER,
               Constants.DATA_GET_ENTIRE_DATA, Constants.DATA_GET_BOARD, Constants.PREVIOUS, Constants.QUIT]))
            pick_option = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
            if pick_option == Constants.DATA_GET_WINNER_INPUT_RATE:
                return_value = MainMenu.__get_winner_data(main_root)
                if return_value == QuitGame:
                    return QuitGame
            elif pick_option == Constants.DATA_GET_SINGLE_PLAYER_INPUT_RATE:
                return_value = MainMenu.__get_game_data(main_root, Constants.SINGLE_PLAYER_DATA)
                if return_value == QuitGame:
                    return QuitGame
            elif pick_option == Constants.DATA_GET_ENTIRE_DATA_INPUT_RATE:
                return_value = MainMenu.__get_game_data(main_root, Constants.ENTIRE_GAME_DATA)
                if return_value == QuitGame:
                    return QuitGame
            elif pick_option == Constants.DATA_GET_BOARD_INPUT_RATE:
                return_value = MainMenu.__get_board_display_after_rounds(main_root)
                if return_value == QuitGame:
                    return QuitGame
                main_root.reset_widgets()  # reset the widgets
            elif pick_option == Constants.PREVIOUS_BOTTOM:
                break  # go back to previous page (game menu)
            elif pick_option == Constants.QUIT_BOTTOM:
                return QuitGame
            else:
                main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again

    @staticmethod
    def __get_winner_data(main_root: GUIMain) -> Any:
        """
        Get winner data.
        """
        flag_of_valid_input = True  # flag for valid input
        while True:
            try:  # For GUI - reset the value of the button, update the message label, add insertion option,
                # update the buttons and start mainloop
                main_root.add_insertion_option(flag_of_valid_input)
                GUIMain.helper_for_setting_gui_for_next_page(main_root, Constants.GAME_ID,
                                                             [Constants.PREVIOUS, Constants.QUIT])
                game_id = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
                if game_id == Constants.PREVIOUS_BOTTOM:
                    break  # go back to previous page (data menu)
                elif game_id == Constants.QUIT_BOTTOM:
                    return QuitGame
                elif game_id == Constants.EMPTY_STRING:
                    flag_of_valid_input = False  # invalid input, change the flag (insertion will be colored in red)
                    main_root.remove_insertion_option()  # remove the insertion option, avoid two insertion options
                    continue
                # means user gave a game id
                winner = LoaderMenu.load_game_winner(game_id)  # get the winner of the game from Loader class
                if winner is False:  # no winner for this game
                    GUIMain.show_message(f"{Constants.DATA_FOR_USER_TITLE}{game_id}", Constants.NO_WINNER)
                    break  # go back to previous page after getting the no winner message
                else:  # there is a winner
                    GUIMain.show_message(f"{Constants.DATA_FOR_USER_TITLE}{game_id}",
                                         f"The winner of game {game_id} is {winner}.")
                    break  # go back to previous page after getting the winner
            except FileNotFoundError:  # game id not found, try again inserting game id
                flag_of_valid_input = False  # insertion will be colored in red
                main_root.remove_insertion_option()  # remove the insertion option, avoid two insertion options
            except Exception as e:  # probably inserted an empty name
                flag_of_valid_input = False
                main_root.show_error(str(e))
                main_root.remove_insertion_option()

    @staticmethod
    def __get_game_data(main_root: GUIMain, option: int) -> Any:
        """
        Get game data.
        """
        flag_of_valid_input = True  # flag for valid input
        while True:
            try:  # For GUI - reset the value of the button, update the message label, add insertion option,
                # update the buttons and start mainloop
                main_root.remove_insertion_option()  # remove the insertion option - avoid two insertion options
                main_root.add_insertion_option(flag_of_valid_input)
                GUIMain.helper_for_setting_gui_for_next_page(main_root, Constants.GAME_ID,
                                                             [Constants.PREVIOUS, Constants.QUIT])
                game_id = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
                if game_id == Constants.PREVIOUS_BOTTOM:
                    break  # go back to previous page (data menu)
                elif game_id == Constants.QUIT_BOTTOM:
                    return QuitGame
                elif game_id == Constants.EMPTY_STRING:
                    flag_of_valid_input = False
                    main_root.remove_insertion_option()
                    continue
                # means user gave a game id
                if option == Constants.SINGLE_PLAYER_DATA:
                    main_root.remove_insertion_option()  # remove the insertion option, avoid two insertion options
                    inner_flag_of_valid_input = True  # inner flag for invalid player name
                    while True:
                        try:  # For GUI - reset the value of the button, update the message label, add insertion option,
                            # update the buttons and start mainloop
                            main_root.add_insertion_option(inner_flag_of_valid_input)
                            GUIMain.helper_for_setting_gui_for_next_page(main_root, Constants.PLAYER_NAME,
                                                                         [Constants.PREVIOUS,
                                                                          Constants.QUIT])
                            player_name = main_root.get_button_value()  # get the value of the button (player name)
                            if player_name == Constants.PREVIOUS_BOTTOM:
                                main_root.remove_insertion_option()  # remove the insertion option, avoid two insertions
                                break
                            elif player_name == Constants.QUIT_BOTTOM:
                                return QuitGame
                            player_data = LoaderMenu.load_game_data(game_id, player_name)
                            if player_data.startswith(Constants.NO_MOVES_ERROR):  # if player not found
                                inner_flag_of_valid_input = False  # invalid player name, change the flag
                                main_root.remove_insertion_option()  # remove the insertion option, avoid two insertions
                                continue
                            GUIMain.show_message(f"{Constants.DATA_FOR_USER_TITLE}{game_id}", player_data)
                            main_root.remove_insertion_option()  # after showing the data, remove the insertion option
                            return  # go back to previous page after getting the player data
                        except FileNotFoundError:  # file not found, try again
                            flag_of_valid_input = False
                            main_root.remove_insertion_option()  # try again inserting the game id
                            break
                else:  # option == MainMenu.ENTIRE_GAME_DATA
                    game_data = LoaderMenu.load_game_data(game_id, None)
                    GUIMain.show_message(f"{Constants.DATA_FOR_USER_TITLE}{game_id}", game_data)
                    break
            except FileNotFoundError:  # game id not found, try again
                flag_of_valid_input = False
                main_root.remove_insertion_option()
            except Exception as e:  # probably inserted an empty name
                flag_of_valid_input = False
                main_root.show_error(str(e))
                main_root.remove_insertion_option()

    @staticmethod
    def __start_new_game(main_root: GUIMain) -> Any:
        """
        Start a new game method.
        """
        while True:
            try:
                # create dict of players via user answer
                dict_of_players = MainMenu.__setting_dict_of_players_from_user(main_root)
                if dict_of_players == QuitGame:
                    return QuitGame
                if dict_of_players == PreviousPage:
                    break  # go back to previous page (game menu)
                new_game = Game(main_root, dict_of_players, Constants.GAME_TYPES[0], None,
                                None, None, None, None)
                game_has_ended = new_game.run_game()  # run the game, assign the game_has_ended variable bool
                while True:
                    if game_has_ended is True:  # if the game has ended and there is a winner
                        if new_game.play_again_question(game_has_ended) is False:
                            # if user refused to play again (else, he will restart the game)
                            return PreviousPage  # go back to previous page (game menu)
            except Quit:
                break

    @staticmethod
    def __setting_dict_of_players_from_user(main_root: GUIMain) -> Any:
        """
        Setting a dict of players from users input data
        """
        while True:
            num_of_players = InputFromUser.new_num_of_players(main_root)  # get the number of players
            if num_of_players == QuitGame:
                return QuitGame
            if num_of_players == PreviousPage:
                return PreviousPage
            elif num_of_players == int(Constants.TWO):
                num_of_pieces_for_player = Constants.ALTERNATE_NUMBER_OF_PIECES
            else:
                num_of_pieces_for_player = Constants.DEFAULT_NUMBER_OF_PIECES
            counter_of_setting_new_player = 0
            dict_of_players: dict[Player, Any] = {}
            list_of_available_colors = Constants.COLORS_IN_GAME.copy()  # list of available colors
            list_of_names: list[str] = []  # list of names of the players
            while counter_of_setting_new_player < num_of_players:
                # repeat the process for each player num_of_players successful times
                list_of_data_for_single_player = (InputFromUser.getting_input_for_a_single_player
                                                  (main_root, num_of_players, list_of_available_colors,
                                                   list_of_names))
                if list_of_data_for_single_player == QuitGame:
                    return QuitGame
                if list_of_data_for_single_player == PreviousPage:
                    break  # breaking the inner loop, asking the user again for the number of players
                # set home triangle for each player (according to the number of players)
                home_triangle =\
                    Constants.HOME_TRIANGLE_FOR_NUM_OF_PLAYERS[num_of_players][counter_of_setting_new_player]
                # create a new player
                try:
                    player = MainMenu.__setting_new_player(list_of_data_for_single_player,
                                                           num_of_pieces_for_player, home_triangle)
                    dict_of_players[player] = list_of_data_for_single_player[3]
                    # add the player to the dictionary with strategy
                    counter_of_setting_new_player += 1  # successful setting, continue to the next player
                    main_root.add_extra_message_label(Constants.SUCCESSFUL_SETTING)
                except Exception as e:
                    main_root.show_error(str(e))  # error while setting the player, try again
                    main_root.show_error(Constants.ERROR_WHILE_PROCESSING)
            if counter_of_setting_new_player == num_of_players:  # all the players have been set successfully
                if main_root.get_extra_message_label() is not None:  # if there is an extra message label
                    main_root.remove_extra_message_label()  # remove the extra message label
                return dict_of_players  # after settings all the players, return the dictionary

    @staticmethod
    def __setting_new_player(list_of_data_for_single_player: list[Any], num_of_pieces_for_player: int,
                             home_triangle: str) -> Player:
        """
        Setting a new player. Getting the data of the player and creating a new player.
        """
        player = Player(list_of_data_for_single_player[1])  # create a new player with its name
        player.set_color(list_of_data_for_single_player[2])  # set the player color
        player.set_number_of_pieces(num_of_pieces_for_player)  # set the number of pieces for the player
        player.set_home_cells(home_triangle)  # set the home triangle for the player
        return player

    @staticmethod
    def __load_previous_game(main_root: GUIMain) -> Any:
        """
        Load a previous game.
        """
        while True:
            try:
                load_game = LoaderMenu.continue_game(main_root, None)
                # getting a game from the Loader class
                main_root.reset_widgets()  # reset the widgets
                game_has_ended = load_game.run_game()  # run the game, assign the game_has_ended variable bool
                while True:
                    if game_has_ended is True:  # if the game has ended and there is a winner
                        if load_game.play_again_question(game_has_ended) is False:
                            # if user refused to play again (else, he will restart the game)
                            return PreviousPage  # go back to previous page (game menu)
                    else:  # if the game has not ended, and user already refused to play again
                        return PreviousPage  # go back to previous page (game menu)
            except Quit:  # if user decided to quit the game by pressing 'q'
                break
            except Exception as e:
                main_root.show_error(str(e))  # other errors, try again

    @staticmethod
    def __get_board_display_after_rounds(main_root: GUIMain) -> Any:
        """
        Get the board display after X rounds.
        """
        try:
            board_to_watch: Board = LoaderMenu.continue_game(main_root, True)
            # getting the board from the Loader class
            main_root.reset_widgets()  # reset the widgets
            main_root.set_board(board_to_watch)  # set the board to the GUI
            main_root.pack_board_in_gui_window()  # pack the board in the GUI window
            main_root.add_extra_message_label(Constants.BOARD_AFTER_ROUNDS)
            main_root.start_main_loop()  # start the main loop
            return  # go back to previous page (game menu)
        except FileNotFoundError:
            main_root.show_error(Constants.FILE_NOT_FOUND)  # file not found, try again
        except Quit:
            return  # go back to previous page (game menu)
        except Exception as e:
            main_root.show_error(str(e))

    @staticmethod
    def __tournament(main_root: GUIMain) -> Any:
        """
        Tournament options: start a new tournament, get previous data.
        """
        while True:
            options = [Constants.NEW_TOURNAMENT, Constants.GET_TOURNAMENT_DATA, Constants.PREVIOUS, Constants.QUIT]
            GUIMain.helper_for_setting_gui_for_next_page(main_root,
                                                         f"{Constants.TOURNAMENT_MENU}\n\n"
                                                         f"{Constants.WOULD_LIKE_TO_DO}", options)
            pick_option = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
            if pick_option == Constants.NEW_TOURNAMENT_INPUT_RATE:  # start a new tournament
                return_value = MainMenu.__start_new_tournament(main_root)
                if return_value == QuitGame:
                    return QuitGame
            elif pick_option == Constants.GET_TOURNAMENT_DATA_INPUT_RATE:  # get data of a tournament
                return_value = MainMenu.__get_data_of_tournament(main_root)
                if return_value == QuitGame:
                    return QuitGame
            elif pick_option == Constants.PREVIOUS_BOTTOM:
                break  # go back to previous page (main menu)
            elif pick_option == Constants.QUIT_BOTTOM:
                return QuitGame
            else:
                main_root.show_error(Constants.INVALID_INPUT)  # invalid input, try again

    @staticmethod
    def __start_new_tournament(main_root: GUIMain) -> Any:
        """
        Start a new tournament.
        """
        while True:
            main_root.remove_insertion_option()  # remove the insertion option - avoid two insertion options
            main_root.remove_extra_message_label()  # remove the extra message label
            list_of_valid_num =\
                [str(i) for i in range(Constants.MIN_NUM_OF_PLAYERS, Constants.MAX_NUM_OF_PLAYERS + 1)]
            list_of_valid_num += [Constants.PREVIOUS, Constants.QUIT]
            GUIMain.helper_for_setting_gui_for_next_page(main_root,
                                                         Constants.TOURNAMENT_EXPLANATION, list_of_valid_num)
            user_input = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
            if user_input == Constants.PREVIOUS_BOTTOM:
                break  # go back to previous page (tournament menu)
            elif user_input == Constants.QUIT_BOTTOM:
                return QuitGame
            else:  # user input is valid
                num_of_players = int(user_input)
                try:
                    main_root.reset_widgets()  # reset the widgets
                    new_tournament = Tournament(main_root, num_of_players)  # create a new tournament
                    new_tournament.run_tournament()  # run the tournament
                    break  # go back to previous page (tournament menu)
                except Quit:  # if user decided to quit the tournament by pressing 'q',
                    continue  # continue (will be asked again about number of players - have the ability to quit)
                except Exception as e:  # other errors, raise the error and continue (number of players question)
                    main_root.show_error(str(e))
                    # other errors, raise the error and continue (number of players question)

    @staticmethod
    def __get_data_of_tournament(main_root: GUIMain) -> Any:
        """
        Get data of a tournament.
        """
        while True:
            list_of_options = [Constants.TOURNAMENT_DATA_WINNER, Constants.TOURNAMENT_DATA_ENTIRE,
                               Constants.TOURNAMENT_DATA_WINNER_A, Constants.TOURNAMENT_DATA_WINNER_B,
                               Constants.TOURNAMENT_DATA_SCORE, Constants.PREVIOUS, Constants.QUIT]
            (GUIMain.helper_for_setting_gui_for_next_page
             (main_root, f"{Constants.TOURNAMENT_DATA}\n\n{Constants.WOULD_LIKE_TO_DO}",
              list_of_options))
            answer = main_root.get_button_value()  # get the value of the button (when clicked loop will stop)
            if answer == Constants.PREVIOUS_BOTTOM:
                break  # go back to previous page (tournament menu)
            elif answer == Constants.QUIT_BOTTOM:
                return QuitGame
            elif answer.isdigit() is False or int(answer) not in Constants.RANGE_OF_OPTIONS_DATA_TOURNAMENT:
                main_root.show_error(Constants.INVALID_INPUT)
                continue  # invalid input, try again
            # means user gave a valid answer
            return_value = MainMenu.__get_data_of_tournament_helper(main_root, int(answer))
            if return_value == QuitGame:
                return QuitGame

    @staticmethod
    def __get_data_of_tournament_helper(main_root: GUIMain, option_of_data: int) -> Any:
        """
        Get data of a tournament.
        """
        flag_of_valid_input = True  # flag for valid input
        while True:
            try:
                main_root.remove_insertion_option()  # remove the insertion option - avoid two insertion options
                main_root.add_insertion_option(flag_of_valid_input)  # add insertion option
                (GUIMain.helper_for_setting_gui_for_next_page
                 (main_root, Constants.TOURNAMENT_ID, [Constants.PREVIOUS, Constants.QUIT]))
                tournament_id = main_root.get_button_value()  # get the value of the button (when clicked loop stop)
                if tournament_id == Constants.PREVIOUS_BOTTOM:
                    main_root.remove_extra_message_label()  # remove the extra message label
                    main_root.remove_insertion_option()  # remove the insertion option
                    break  # go back to previous page (data menu)
                elif tournament_id == Constants.QUIT_BOTTOM:
                    return QuitGame
                elif tournament_id == Constants.EMPTY_STRING:
                    flag_of_valid_input = False  # invalid input, change the flag (insertion will be colored in red)
                    main_root.add_extra_message_label(Constants.INVALID_INPUT, Constants.ERROR_COLOR)
                    continue
                # means user gave a tournament id
                tournament_data = LoaderMenu.load_tournament_data(tournament_id, option_of_data)
                main_root.show_message(f"{Constants.DATA_FOR_USER_TITLE}{tournament_id}", tournament_data)
                main_root.remove_insertion_option()  # remove the insertion option
                main_root.remove_extra_message_label()  # remove the extra message label
                break  # go back to previous page after getting the data (either data or not)
            except FileNotFoundError:
                flag_of_valid_input = False  # file not found, change the flag (insertion will be colored in red)
                main_root.add_extra_message_label(Constants.FILE_NOT_FOUND, Constants.ERROR_COLOR)
            except Exception as e:  # probably inserted an empty name
                flag_of_valid_input = False
                main_root.show_error(str(e))  # other errors, try again


if __name__ == "__main__":
    # when running python main.py --help, the description will be shown
    parser = argparse.ArgumentParser(description=Constants.DESCRIPTION)
    args = parser.parse_args()

    MainMenu.main_menu(GUIMain())
