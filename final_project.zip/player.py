#############################################################
# FILE : player.py
# WRITER : Avichai Bitter , bitter710 , 211329404
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: player class for chinese checkers game
#############################################################
from piece import Piece
from constants import *
from typing import Any


class Player:

    """A class representing a player in Chinese Checkers. initialized with a name and default data. User can set the
    color, the number of pieces and the home cells. In addition, user can check if player wins and
    reset the pieces to home cells. The class has some methods that can be used in other classes, like
    MainMenu, Game and Tournament.
    """

    def __init__(self, name: str) -> None:
        """A constructor for the player class. it initialized with a name, and if user doesn't set num of pieces
         or home cells, the constructor sets default values. main function will set the data of every player,
          and sends it to the game class.
        """
        if isinstance(name, str) and len(name) > 0:
            if not name[0].isalpha():  # name first char is not a letter
                raise ValueError(Constants.NAME_FIRST_CHAR)
            if " " in name:  # name has more than one word
                raise ValueError(Constants.NAME_ONE_WORD)
            name = name[0].upper() + name[1:]  # capitalize the first letter of the name
            self.__name: str = name
        else:
            raise ValueError(Constants.ILLEGAL_NAME)
        self.__number_of_pieces = Constants.DEFAULT_NUMBER_OF_PIECES
        # Will be refilled every single game (main class).
        self.__color: str = Constants.DEFAULT_COLOR
        # every player has default white color. Will be assigned in the main class.
        self.__number_of_wins: int = Constants.INIT_NUM_OF_WINS
        self.__number_of_losses: int = Constants.INIT_NUM_OF_LOSES
        self.__home_cells: list[tuple[int, int]] = Constants.DICT_OF_TRIANGLES["1"]
        self.__target_cells: list[tuple[int, int]] = Constants.DICT_OF_TRIANGLES["4"]
        # in default, every player has the upper home cells. Will be refilled and set every single game.
        self.__pieces_of_player: list[Piece] = self.set_pieces()
        # in default, every player has 10 pieces (in the upper triangle). Will be refilled and set every single game.

    def get_name(self) -> str:
        """A method that returns the name of the player.
        """
        return self.__name

    def set_color(self, color: str) -> None:
        """A method that sets the color of the player.
        """
        if color in Constants.COLORS_IN_GAME:
            self.__color = color
            self.__pieces_of_player = self.set_pieces()  # update the pieces
        else:
            raise ValueError(Constants.ILLEGAL_COLOR)
        # Will be refilled every single game (main class). General note: if Exception is raised,
        # the program will shut down. Means that every class that uses the player class, should handle the exception.

    def get_color(self) -> str:
        """A method that returns the color of the player.
        """
        return self.__color

    def set_number_of_pieces(self, num_of_pieces: int) -> None:
        """A method that sets the number of pieces of the player.
        """
        if isinstance(num_of_pieces, int) and (num_of_pieces == Constants.DEFAULT_NUMBER_OF_PIECES
                                               or num_of_pieces == Constants.ALTERNATE_NUMBER_OF_PIECES):
            # every player in the game has to have 10 pieces (or 15 in one vs one game)
            self.__number_of_pieces = num_of_pieces
            if self.__number_of_pieces == Constants.DEFAULT_NUMBER_OF_PIECES:
                self.set_home_cells("1")  # the home cells should be 1, and target cells will be 4
            else:
                self.set_home_cells("A")  # the home cells should be A, and target cells will be B
            self.__pieces_of_player = self.set_pieces()  # update the pieces
        else:
            raise ValueError(Constants.ILLEGAL_NUM_OF_PIECES)
        # Will be refilled every single game (main class). General note: if Exception is raised,
        # the program will shut down. Means that every class that uses the player class, should handle the exception.

    def set_home_cells(self, home_cells: str) -> None:
        """A method that sets the home cells of the player. If user doesn't set home cells,
         the constructor sets default. Method also sets the target cells.
        """
        if home_cells in Constants.DICT_OF_TRIANGLES and len(home_cells) == 1:  # checking if home cells is legal
            if self.__number_of_pieces == Constants.DEFAULT_NUMBER_OF_PIECES and home_cells.isdigit() is True:
                #  if the number of pieces is default, the home cells should be 1 - 6
                self.__home_cells = Constants.DICT_OF_TRIANGLES[home_cells]
                self.__pieces_of_player = self.set_pieces()
                if int(home_cells) <= Constants.OPPOSITE_TRIANGLE_KEY:  # setting the target cells as opposite triangle
                    self.__target_cells = Constants.DICT_OF_TRIANGLES[str(int(home_cells)
                                                                          + Constants.OPPOSITE_TRIANGLE_KEY)]
                else:
                    self.__target_cells = Constants.DICT_OF_TRIANGLES[str(int(home_cells)
                                                                          - Constants.OPPOSITE_TRIANGLE_KEY)]
            elif self.__number_of_pieces == Constants.ALTERNATE_NUMBER_OF_PIECES and home_cells.isalpha() is True:
                #  if the number of pieces is alternate, the home cells should be A - B
                self.__home_cells = Constants.DICT_OF_TRIANGLES[home_cells]
                self.__pieces_of_player = self.set_pieces()
                if home_cells == "A":  # setting the target cells as the opposite triangle
                    self.__target_cells = Constants.DICT_OF_TRIANGLES["B"]
                else:  # means "B" (other options have been filtered in the if statement)
                    self.__target_cells = Constants.DICT_OF_TRIANGLES["A"]
            else:
                raise ValueError(Constants.PAY_ATTENTION_HOME_CELLS)

        else:
            raise ValueError(Constants.ILLEGAL_HOME_CELLS)
        # Will be refilled every single game (main class). General note: if Exception is raised,
        # the program will shut down. Means that every class that uses the player class, should handle the exception.

    def set_pieces(self) -> list[Piece]:
        """A method that sets the pieces of the player. If user doesn't set num of pieces, the constructor sets default.
        """
        pieces_of_player: list[Piece] = []
        for i in range(self.__number_of_pieces):  # creating the pieces of the player
            piece_to_append = Piece(self.__color, i + 1, self.__home_cells[i])
            pieces_of_player.append(piece_to_append)
        return pieces_of_player

    def reset_pieces_for_next_game(self) -> None:
        """A method that resets the pieces of the player for the next game, means the pieces itself will be
         moved to home_cells. if user want to change color, num of pieces for the next game, he can set it manually.
        """
        for i in range(len(self.__pieces_of_player)):
            self.__pieces_of_player[i].move(self.__home_cells[i])

    def __set_win(self) -> None:
        """A method that sets the number of wins of the player.
        """
        self.__number_of_wins += 1

    def get_score_of_player(self) -> str:
        """A method that returns the score of the player.
        """
        win_word = "win" if self.__number_of_wins == 1 else "wins"
        lose_word = "lose" if self.__number_of_losses == 1 else "losses"
        return f"{self.__name} has {self.__number_of_wins} {win_word} and {self.__number_of_losses} {lose_word}"
        # paying attention to the singular form

    def get_pieces_of_player(self) -> list[Piece]:
        """A method that returns the pieces of the player.
        """
        return self.__pieces_of_player

    def get_target_triangle(self) -> str:
        """A method that returns the target triangle of the player.
        """
        target_triangle = ""  # finding the target triangle of the player
        for key, value in Constants.DICT_OF_TRIANGLES.items():
            if self.__target_cells == value:  # checking which triangle is the target triangle
                target_triangle = key
        return target_triangle

    def get_home_triangle(self) -> str:
        """A method that returns the home triangle of the player.
        """
        home_triangle = ""  # finding the home triangle of the player
        for key, value in Constants.DICT_OF_TRIANGLES.items():
            if self.__home_cells == value:  # checking which triangle is the home triangle
                home_triangle = key
        return home_triangle

    def is_player_win(self, only_for_check: Any = None) -> bool:
        """A method that returns True if the player wins, and False otherwise.
        """
        for piece in self.__pieces_of_player:  # checking if all the pieces are in the target cells
            if piece.get_coordinate() not in self.__target_cells:
                return False
        if only_for_check is None:  # if the method is called from the game class, the player wins should be set
            self.__set_win()  # if all the pieces are in the target cells, the player wins
        return True

    def increment_losses(self) -> None:
        """A method that increments the number of losses of the player.
        """
        self.__number_of_losses += 1

    def check_if_all_pieces_in_home_cells(self) -> bool:
        """A method that returns True if all the pieces are in the home cells, and False otherwise.
        """
        for piece in self.__pieces_of_player:
            if piece.get_coordinate() not in self.__home_cells:
                return False  # if at least one piece is not in the home cells, the player can't start the game
        return True
